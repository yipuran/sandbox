package org.talking;

import java.io.IOException;
import java.util.Arrays;

public class TalkMain {

	public static void main(String[] args) {
		Arrays.stream(args).map(e->"【"+e+"】").forEach(System.out::println);
		try {
			String str = StdKeyUtil.getKeyin("-->");
			System.out.println(str.toUpperCase());
		}catch(IOException e){
			e.printStackTrace();
		}
	}

}
