package com.demo.batch.entity;

/**
 * Employee
 */
public class Employee {
   private String firstName;
   private String lastName;
   private int age;
   private int salary;

   public String getFirstName() {
       return firstName;
   }

   public void setFirstName(String firstName) {
       this.firstName = firstName;
   }

   public String getLastName() {
       return lastName;
   }

   public void setLastName(String lastName) {
       this.lastName = lastName;
   }

   public int getAge() {
       return age;
   }

   public void setAge(int age) {
       this.age = age;
   }

   public int getSalary() {
       return salary;
   }

   public void setSalary(int salary) {
       this.salary = salary;
   }
}