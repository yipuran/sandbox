/**
 * package-info
 */
package com.demo.batch.entity;