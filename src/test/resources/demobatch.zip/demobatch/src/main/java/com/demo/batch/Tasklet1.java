package com.demo.batch;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.demo.batch.logic.Setting;


@Component
public class Tasklet1 implements Tasklet {

	@Autowired
	private Setting setting;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		System.out.println("tasklet 1 !!");

		System.out.println("group = "+setting.getGroup());

		System.out.println("name  = "+setting.name);

		System.out.println("clist = "+setting.getClist());

		return RepeatStatus.FINISHED;
	}

	public Setting getSetting() {
		return setting;
	}

}