package com.demo.batch;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;

/**
 * SampleBatchApplication2
 *
 * mainメソッドクラスを複数で構成する場合、Bean名、stepXxxx ,  jobXxxx , listnerXxx が重複しないように持つ！！
 *
 */
@SpringBootApplication
@EnableBatchProcessing
@EnableAutoConfiguration(exclude={DataSourceAutoConfiguration.class})
public class SampleBatchApplication2 {
	@Autowired private Tasklet1 tasklet1;
	@Autowired private Tasklet2 tasklet2;
	@Autowired private Hello hello;
	@Autowired private JobBuilderFactory jobBuilderFactory;
	@Autowired private StepBuilderFactory stepBuilderFactory;

	@Bean
	public Step step11() {
		return stepBuilderFactory.get("step11")
				.tasklet(tasklet1)
				.build();
	}

	@Bean
	public Step step12() {
		return stepBuilderFactory.get("step12")
				.tasklet(tasklet2)
				.build();
	}
	@Bean
	public Step stepHello2() {
		return stepBuilderFactory.get("hello")
				.tasklet(hello)
				.build();
	}

	@Bean
	public Job job2(Step step11, Step step12) throws Exception {
		return jobBuilderFactory.get("job2")
				.incrementer(new RunIdIncrementer())
				.listener(listener2())
				.start(step11)
				.next(step12)
				.next(stepHello2())
				.build();
	}
	@Bean
	public JobExecutionListener listener2() {
		return new JobListener();
	}


    public static void main(String[] args) throws Exception {
        // System.exit is common for Batch applications since the exit code can be used to
        // drive a workflow
        System.exit(SpringApplication.exit(SpringApplication.run(SampleBatchApplication2.class, args)));
    }

}
