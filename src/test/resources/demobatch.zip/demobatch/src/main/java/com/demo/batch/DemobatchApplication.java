package com.demo.batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemobatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemobatchApplication.class, args);
//		SpringApplication application = new SpringApplication(DemobatchApplication.class);
//		application.setWebApplicationType(WebApplicationType.NONE);
//		ApplicationContext ctx = application.run();
//		SpringApplication.exit(ctx);

//		 ApplicationContext context = new AnnotationConfigApplicationContext(BatchConfiguration.class);
//       JobLauncher jobLauncher = context.getBean(JobLauncher.class);
//       Job job = context.getBean("Hello", Job.class);
//       JobParameters jobParameters = new JobParametersBuilder().toJobParameters();
//       try{
//           JobExecution jobExecution = jobLauncher.run(job, jobParameters);
//       }catch(Exception e) {
//           e.printStackTrace();
//       }

	}

}
