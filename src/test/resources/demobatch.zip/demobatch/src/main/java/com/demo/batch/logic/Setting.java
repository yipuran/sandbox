package com.demo.batch.logic;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Setting
 */
@ConfigurationProperties(prefix="address")
@Component
public class Setting{

	public Map<String, Object> group;

	@Value("${aaa.bbb}")
	public String name;

	private List<Integer> clist = new ArrayList<>();
	public List<Integer> getClist(){
		return clist;
	}


	public void setGroup(Map<String, Object> m) {
		group = m;
	}

	public Map<String, Object> getGroup(){
		return group;
	}
}
