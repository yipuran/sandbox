package com.demo.batch;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.test.context.junit4.SpringRunner;

import com.demo.batch.logic.Setting;

/**
 * Tasklet1Test
 */
//@RunWith(SpringJUnit4ClassRunner.class)
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {Setting.class}, initializers = ConfigFileApplicationContextInitializer.class)
@SpringJUnitConfig
@EnableAutoConfiguration
class Tasklet1Test{
	@Autowired
	public ApplicationContext ctx;
	private Tasklet1 tasklet1;

	@BeforeEach
	void setUp() throws Exception{
		tasklet1 = ctx.getAutowireCapableBeanFactory().createBean(Tasklet1.class);
	}

	@Test
	void testExecute(){
		assertTrue(true);
		Setting setting = tasklet1.getSetting();
		assertEquals("ABC", setting.name);
		Map<String, Object> map = setting.group;
		assertEquals("A", map.get("info1"));
		assertEquals(120, map.get("info2"));
		assertArrayEquals(new Integer[] {21, 22, 23}, setting.getClist().toArray(new Integer[]{}));

		try{
			tasklet1.execute(null, null);
		}catch(Exception e){
			e.printStackTrace();
			fail();
		}
	}

}
