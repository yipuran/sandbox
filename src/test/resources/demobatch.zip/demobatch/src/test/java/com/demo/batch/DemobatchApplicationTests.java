package com.demo.batch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemobatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
