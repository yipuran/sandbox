package org.dbtest.mapper;

import java.util.List;

import org.dbtest.entity.Game;

import com.google.inject.ImplementedBy;

/**
 * SimpleDao
 */
@ImplementedBy(SimpleDaoImpl.class)
public interface SimpleDao{
	public List<Game> getGames();
	public void updateGame(Game game);
}
