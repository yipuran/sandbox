package org.dbtest.base;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;

import lombok.Getter;

/**
 * BaseDao
 */
@Getter
public abstract class BaseDao{
	@Inject private SqlSession sqlSession;
}
