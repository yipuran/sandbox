package org.dbtest.entity;

import java.time.LocalDateTime;

import lombok.Data;

/**
 * Game
 */
@Data
public class Game{
	private int id;
	private String itemName;
	private int dispPrice;
	private int calprice;
	private LocalDateTime createAt;
}
