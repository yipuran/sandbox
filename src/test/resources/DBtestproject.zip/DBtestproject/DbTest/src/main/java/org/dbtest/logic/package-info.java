/**
 * 各機能のロジックパッケージ
 */
package org.dbtest.logic;