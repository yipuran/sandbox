package org.dbtest;

import org.dbtest.base.LogicBuilder;
import org.dbtest.logic.Logic;
import org.dbtest.logic.LogicImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.inject.AbstractModule;
import com.google.inject.name.Names;

/**
 * DbTestMain
 */
public class DbTestMain3{

	public static void main(String[] args){
		Logger logger = LoggerFactory.getLogger(DbTestMain3.class);
		logger.debug("■■■ DbTestMain");

		LogicBuilder<Logic> builder = new LogicBuilder<>(
			new AbstractModule(){
				@Override
				protected void configure() {
					binder().bind(String.class).annotatedWith(Names.named("TEST")).toInstance("テスト");
				}
			}
		);
		try{
			Logic logic = builder.get(LogicImpl.class);
			logic.execute();
			logger.debug("■■■ update()");
			logic.update();
			logger.info("■■■ update After ■■■");
			logic.execute();
		}catch(Exception x){
			logger.error("■■■ catch Exception : "+x.getMessage());
			logger.error(x.getMessage(), x);
		}
	}

}
