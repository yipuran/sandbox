package org.dbtest.mapper;

/**
 * SimpleMapper
 */
public interface SimpleMapper{
}
