package org.dbtest.logic;

import java.util.List;

import javax.inject.Inject;

import org.dbtest.entity.Game;
import org.dbtest.mapper.SimpleDao;
import org.mybatis.guice.transactional.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * LogicImpl
 */
public class LogicImpl implements Logic{
	Logger logger = LoggerFactory.getLogger(this.getClass());
	@Inject private SimpleDao dao;

	// for DbTestMain3
	//@Inject @Named("TEST") String param;

	@Override
	public void execute(){
		List<Game> list = dao.getGames();
		list.stream().forEach(e->logger.info(e.toString()));
	}

	@Transactional
	@Override
	public void update(){
		List<Game> list = dao.getGames();
		Game game = list.stream().filter(e->e.getId()==2).findAny().get();

		logger.info(game.toString());
		game.setDispPrice(600);
		dao.updateGame(game);

		//game.setItemName(null);
		//dao.updateGame(game);

		// for DbTestMain3
		//logger.debug("### param = "+ param);
	}

}
