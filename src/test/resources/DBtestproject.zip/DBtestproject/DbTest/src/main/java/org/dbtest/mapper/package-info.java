/**
 * マッパーとDAO実装を置く
 *
 * DAOインターフェースと実装、マッパーを書く。
 *
 * public class XxxxDaoImpl extends BaseDao implements XxxxDao
 *
 * @ImplementedBy(XxxxDaoImpl.class)
 * public interface XxxxDao
 *
 * とする
 *
 */
package org.dbtest.mapper;
