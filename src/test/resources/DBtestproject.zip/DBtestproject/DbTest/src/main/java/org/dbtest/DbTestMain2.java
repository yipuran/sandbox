package org.dbtest;

import org.dbtest.base.LogicBuilder;
import org.dbtest.logic.Logic;
import org.dbtest.logic.LogicImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * DbTestMain
 */
public class DbTestMain2{

	public static void main(String[] args){
		Logger logger = LoggerFactory.getLogger(DbTestMain2.class);
		logger.debug("■■■ DbTestMain");

		LogicBuilder<Logic> builder = new LogicBuilder<>();
		try{
			Logic logic = builder.get(LogicImpl.class);
			logic.execute();
			logger.debug("■■■ update()");
			logic.update();
			logger.info("■■■ update After ■■■");
			logic.execute();
		}catch(Exception x){
			logger.error("■■■ catch Exception : "+x.getMessage());
			logger.error(x.getMessage(), x);
		}
	}

}
