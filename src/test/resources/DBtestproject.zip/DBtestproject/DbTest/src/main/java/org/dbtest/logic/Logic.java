package org.dbtest.logic;

/**
 * Logic
 */
public interface Logic{
	public void execute();

	public void update();

}
