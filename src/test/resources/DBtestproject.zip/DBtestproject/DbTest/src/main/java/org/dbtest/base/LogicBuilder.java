package org.dbtest.base;

import org.mybatis.guice.XMLMyBatisModule;

import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Module;

/**
 * LogicBuilder
 */
public class LogicBuilder<T>{

	private Injector injector;

	public LogicBuilder(){
		injector = Guice.createInjector(new XMLMyBatisModule(){
			@Override
			protected void initialize(){
			}
		});
	}
	public LogicBuilder(Module...modules){
		injector = Guice.createInjector(new XMLMyBatisModule(){
			@Override
			protected void initialize(){
			}
		}).createChildInjector(modules);
	}

	public T get(Class<? extends T> cls){
		return injector.getInstance(cls);
	}
}
