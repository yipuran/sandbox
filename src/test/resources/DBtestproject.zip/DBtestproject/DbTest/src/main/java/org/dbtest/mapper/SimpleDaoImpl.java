package org.dbtest.mapper;

import java.util.List;

import org.dbtest.base.BaseDao;
import org.dbtest.entity.Game;

/**
 * SimpleDaoImpl
 */
public class SimpleDaoImpl extends BaseDao implements SimpleDao{

	@Override
	public List<Game> getGames(){
		return getSqlSession().selectList(SimpleMapper.class.getName() +"." + "getGames");
	}

	@Override
	public void updateGame(Game game) {
		getSqlSession().update(SimpleMapper.class.getName() +"." + "updateGame", game);
	}
}
