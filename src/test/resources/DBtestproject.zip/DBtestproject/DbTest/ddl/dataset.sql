TRUNCATE TABLE t_games;
INSERT t_games ( item_name , disp_price , calprice )
VALUES
 ( 'バイク', 12000, 30000 ),
 ( 'クロワッサン', 120, 200 )
 ;
commit;
SELECT * FROM t_games;
