DELIMITER //
DROP TABLE IF EXISTS sakila.t_games
//
CREATE TABLE sakila.t_games(
  id                    INT  NOT NULL AUTO_INCREMENT
, item_name             VARCHAR(40) NOT  NULL
, disp_price            INT NOT NULL DEFAULT 0
, calprice              INT NOT NULL DEFAULT 0
, create_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP
, PRIMARY KEY (id)
 ) ENGINE=InnoDB  DEFAULT CHARSET='UTF8MB4' COLLATE='utf8mb4_general_ci'
//
DELIMITER ;