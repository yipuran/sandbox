package jp.career_tasu.bs810;

/**
 * FakeAWSBatch
 */
public class FakeAWSBatch extends AWSBatch{
	private String requestStr;
	@Override
	public SubmitJobResult submitJob(SubmitJobRequest request) {

		requestStr = request.getName()+"_"+request.getQueue()+"_"+request.getDefine();


		return new FakeSubmitJobResult();
	}

	public String getReqString() {

		return requestStr;
	}
}
