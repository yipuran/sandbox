

/**
 * FakeAWSBatch
 */
public class FakeAWSBatch extends AWSBatch{

	@Override
	public SubmitJobResult submitJob(SubmitJobRequest request) {
		return new FakeSubmitJobResult();
	}
}
