package jp.career_tasu.bs810;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import com.amazonaws.services.batch.AWSBatch;
//import com.amazonaws.services.batch.AWSBatchClientBuilder;
//import com.amazonaws.services.batch.model.SubmitJobRequest;
//import com.amazonaws.services.batch.model.SubmitJobResult;

/**
 * キャリタスUCアップ_トリガ
 * @author yamada
 */
public class Bs801Trigger {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    public String exec(){

   	 AWSBatch client = AWSBatchClientBuilder.standard().withRegion("region").build();
       SubmitJobRequest request = new SubmitJobRequest().withJobName("name")
                  .withJobQueue("quename")
                  .withJobDefinition("def");
          SubmitJobResult response = client.submitJob(request);
          String res =  response.getJobId();


          return res;

    }
}