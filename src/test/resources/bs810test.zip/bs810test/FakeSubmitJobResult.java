
/**
 * FakeSubmitJobResult
 */
public class FakeSubmitJobResult extends SubmitJobResult{

	@Override
	public String getJobId() {
		return "A";
	}
}
