
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

/**
 * Bs801TriggerTest
 */
@RunWith(JUnit4.class)
public class Bs801TriggerTest{

	@Before
	public void before() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void case1() {
		try(MockedStatic<AWSBatchClientBuilder> mocked = Mockito.mockStatic(AWSBatchClientBuilder.class)){
			mocked.when(()->AWSBatchClientBuilder.standard()).thenReturn(new FakeAWSBatchClientBuilder());


			Bs801Trigger trigger = new Bs801Trigger();

			Assert.assertEquals("A", trigger.exec());



		}catch(Exception e){
			e.printStackTrace();
			Assert.fail();
		}
	}

}
