package jp.career_tasu.bs810;

/**
 * FakeAWSBatchClientBuilder
 */
public class FakeAWSBatchClientBuilder extends AWSBatchClientBuilder{

	private FakeAWSBatch batch;

	@Override
	public AWSBatch build() {
		batch = new FakeAWSBatch();
		return batch;
	}
	public String spy() {
		return batch.getReqString();
	}
}
