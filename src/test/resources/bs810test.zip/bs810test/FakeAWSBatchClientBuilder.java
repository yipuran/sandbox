
/**
 * FakeAWSBatchClientBuilder
 */
public class FakeAWSBatchClientBuilder extends AWSBatchClientBuilder{

	@Override
	public AWSBatch build() {
		return new FakeAWSBatch();
	}
}
