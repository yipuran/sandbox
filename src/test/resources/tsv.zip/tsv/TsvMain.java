package org.labo.csv;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * TsvMain
 */
public class TsvMain{

	/**
	 * @param args
	 */
	public static void main(String[] args){
		List<String[]> list = new ArrayList<>();

		list.add(new String[] {"A", "B", "C"});
		list.add(new String[] {"A", "B", "C"});
		list.add(new String[] {"A", "B", "C"});

		TsvCreater t = ()->()->list;

		try(OutputStream out = new FileOutputStream("sample.tsv")){
		   t.createWithDblQuot(out, "MS932");
		}catch(Exception e){
		   e.printStackTrace();
		}

	}

}
