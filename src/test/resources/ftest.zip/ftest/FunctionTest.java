package org.yipuran.function;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
	ThrowableConsumerTest.class,
	ThrowableFunctionTest.class,

})

public class FunctionTest {

}
