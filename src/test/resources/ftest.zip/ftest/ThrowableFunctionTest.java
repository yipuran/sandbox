package org.yipuran.function;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Test;

public class ThrowableFunctionTest {

	@Test(expected=RuntimeException.class)
	public void throwTest() {
		Arrays.asList("1", "A", "2").stream()
		.map(ThrowableFunction.of(e->Integer.parseInt(e)))
		.forEach(e->{
			Assert.assertEquals(true, e==1);
		});
	}
	@Test
	public void catchTest() {
		List<Integer> clist = new ArrayList<>();
		clist.add(1);
		clist.add(0);
		clist.add(2);
		List<Integer> reslist = new ArrayList<>();
		Arrays.asList("1", "A", "2").stream()
		.map(ThrowableFunction.of(e->Integer.parseInt(e),
				(e, x)->{
					Assert.assertThat(x, CoreMatchers.instanceOf(NumberFormatException.class));
					return 0;
				}
			)
		).forEach(e->reslist.add(e));
		Assert.assertThat(reslist, CoreMatchers.is(clist));
	}
	@Test
	public void andThen() {
		List<Integer> clist = new ArrayList<>();
		clist.add(1);
		clist.add(0);
		clist.add(2);
		List<Integer> reslist = new ArrayList<>();
		ThrowableFunction<String, Integer> ft = e->Integer.parseInt(e);
		Arrays.asList("1", "A", "2").stream()
		.map(ft.andThen(e->e, (e, x)->{
				Assert.assertThat(x, CoreMatchers.instanceOf(NumberFormatException.class));
				return 0;
			})
		).forEach(e->reslist.add(e));
		Assert.assertThat(reslist, CoreMatchers.is(clist));
	}

	@Test
	public void compose() {
		List<Integer> clist = new ArrayList<>();
		clist.add(1);
		clist.add(0);
		clist.add(2);
		List<Integer> reslist = new ArrayList<>();
		ThrowableFunction<String, Integer> ft = e->Integer.parseInt(e);
		Arrays.asList("1", "A", "2").stream()
		.map(ft.compose(e->e, (e, x)->{
				Assert.assertThat(x, CoreMatchers.instanceOf(NumberFormatException.class));
				return 0;
			})
		).forEach(e->reslist.add(e));
		Assert.assertThat(reslist, CoreMatchers.is(clist));
	}
	@Test
	public void identity() {
		List<String> clist = Arrays.asList("1", "A", "2");
		List<String> reslist = new ArrayList<>();
		Arrays.asList("1", "A", "2").stream()
		.map(ThrowableFunction.identity()
		).forEach(e->reslist.add(e));
		Assert.assertThat(reslist, CoreMatchers.is(clist));
	}
}
