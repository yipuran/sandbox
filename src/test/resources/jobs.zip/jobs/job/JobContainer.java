package org.labo.awsjob.job;

import java.util.List;
import java.util.Map;

import lombok.Data;

/**
 * JobContainer
 */
@Data
public class JobContainer{
	private String image;
	private List<String> command;
	private String statusReason;
	private String executionRoleArn;
	private List<Map.Entry<String, String>> environment;
	private int exitCode;
	private String taskArn;
	private String logStreamName;
	private List<Map<String, String>> resourceRequirements;
	private Map<String, Object> logConfiguration;
}
