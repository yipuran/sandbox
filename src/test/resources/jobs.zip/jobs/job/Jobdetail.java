package org.labo.awsjob.job;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import lombok.Data;

/**
 * Jobdetail
 */
@Data
public class Jobdetail{
	private String jobArn;
	private String jobName;
	private String jobId;
	private String jobQueue;
	private String jobDefinition;
	private Jobstate status;
	private LocalDateTime createdAt;
	private LocalDateTime startedAt;
	private LocalDateTime stoppedAt;
	private JobContainer container;
	private List<String> jobDependOn;
	private Map<String, String> parameters;
	private Map<String, Integer> timeout;
	private Map<String, String> tags;
	private List<String> platformCapabilities;
	private boolean propagateTags;
}
