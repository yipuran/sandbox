package org.labo.awsjob.job;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import lombok.Data;

/**
 * JobStatus
 */
@Data
public class JobStatus implements Serializable{
	private String version;
	private String id;
	private String detailType;
	private String source;
	private String account;
	private LocalDateTime time;
	private String region;
	private List<String> resources;
	private Jobdetail detail;


}
