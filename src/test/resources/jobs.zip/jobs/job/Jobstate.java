package org.labo.awsjob.job;

/**
 * Jobstate
 */
public enum Jobstate{
	SUBMITTED, PENDING, RUNNABLE, STARTING, RUNNING, SUCCEEDED, FAILED ;
}
