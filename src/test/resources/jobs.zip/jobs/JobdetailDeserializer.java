package org.labo.awsjob;

import java.io.IOException;
import java.time.Instant;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Spliterator;
import java.util.Spliterators;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.labo.awsjob.job.JobContainer;
import org.labo.awsjob.job.Jobdetail;
import org.labo.awsjob.job.Jobstate;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * JobdetailDeserializer
 */
public class JobdetailDeserializer extends JsonDeserializer<Jobdetail>{

	@Override
	public Jobdetail deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JacksonException{
		ObjectMapper mapper = new ObjectMapper();
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		Jobdetail detail = new Jobdetail();
	   JsonNode node = p.readValueAsTree();
      detail.setJobArn(node.get("jobArn").textValue());
      detail.setJobName(node.get("jobName").textValue());
      detail.setJobDefinition(node.get("jobDefinition").asText());
      detail.setJobQueue(node.get("jobQueue").asText());
      String status = node.get("status").asText();
      detail.setStatus(Arrays.stream(Jobstate.values()).filter(e->e.name().equals(status)).findAny().get());
      detail.setCreatedAt(Instant.ofEpochMilli(node.get("createdAt").asLong()).atZone(ZoneId.systemDefault()).toLocalDateTime());
      detail.setStartedAt(Instant.ofEpochMilli(node.get("startedAt").asLong()).atZone(ZoneId.systemDefault()).toLocalDateTime());
      detail.setStoppedAt(Instant.ofEpochMilli(node.get("stoppedAt").asLong()).atZone(ZoneId.systemDefault()).toLocalDateTime());
      JobContainer jcon = mapper.convertValue(node.get("container"), new TypeReference<JobContainer>(){});
      detail.setContainer(jcon);
      List<String> jobDependOn = StreamSupport.stream(Spliterators.spliteratorUnknownSize(node.get("dependsOn").elements(), Spliterator.ORDERED), false)
      .filter(n->n.has("jobId")).map(n->n.get("jobId").asText()).collect(Collectors.toList());
      detail.setJobDependOn(jobDependOn);
      detail.setParameters(mapper.convertValue(node.get("parameters"), new TypeReference<Map<String, String>>(){}));
      detail.setTimeout(mapper.convertValue(node.get("timeout"), new TypeReference<Map<String, Integer>>(){}));
      detail.setTags(mapper.convertValue(node.get("tags"), new TypeReference<Map<String, String>>(){}));
      detail.setPlatformCapabilities(mapper.convertValue(node.get("platformCapabilities"), new TypeReference<List<String>>(){}));
		return detail;
	}

}
