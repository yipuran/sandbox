package org.labo.awsjob;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import org.labo.awsjob.job.JobStatus;
import org.labo.awsjob.job.Jobdetail;
import org.yipuran.file.IPath;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;

/**
 * ParseJobsMain1
 */
public class ParseJobsMain1{
	public static void main(String[] args){
		String jsontxt = IPath.readText("sample.json");
		System.out.println(jsontxt);
		System.out.println("------------------");
		try{
			JavaTimeModule jtm = new JavaTimeModule();
			jtm.addDeserializer(LocalDate.class, new LocalDateDeserializer(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
			jtm.addDeserializer(LocalDateTime.class, new LocalDateTimeDeserializer(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'")));
			jtm.addDeserializer(Jobdetail.class, new JobdetailDeserializer());

			ObjectMapper mapper = new ObjectMapper().registerModule(jtm);
			mapper.setPropertyNamingStrategy(PropertyNamingStrategies.KEBAB_CASE);
			mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
			mapper.configure(JsonReadFeature.ALLOW_UNQUOTED_FIELD_NAMES.mappedFeature(), true);

			JobStatus status = mapper.readValue(jsontxt, JobStatus.class);
			System.out.println(status);

			System.out.println(status.getDetail().getContainer().getImage());
			List<Map.Entry<String, String>> envs = status.getDetail().getContainer().getEnvironment();
			envs.stream().forEach(e->{
				System.out.println(e.getKey() + " --> " +e.getValue());
			});
			System.out.println("region : "+status.getRegion());
			System.out.println("createdAt : " + status.getDetail().getCreatedAt() );
			System.out.println("startedAt : " + status.getDetail().getStartedAt() );
			System.out.println("stoppedAt : " + status.getDetail().getStoppedAt() );
			System.out.println("STATUS = " + status.getDetail().getStatus() );
			System.out.println("jobQueue = " + status.getDetail().getJobQueue() );
			System.out.println(status.getDetail().getJobDependOn() );
			System.out.println(status.getDetail().getJobDefinition() );

			System.out.println(status.getDetail().getTimeout() );
			System.out.println("JobName = " + status.getDetail().getJobName() );
			System.out.println("tags = " + status.getDetail().getTags() );
			System.out.println("propagateTags = " + status.getDetail().isPropagateTags() );


		}catch(JsonProcessingException e){
			e.printStackTrace();
		}




	}

}
