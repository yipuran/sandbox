# -*- coding: UTF-8 -*-
from PIL import Image, ImageFilter
import io
import sys

img = Image.open('lena.png')
#print(img.format, img.size, img.mode)
#print(img.getextrema())

# 白黒変換、ガウシアンブラー
img2 = img.convert('L').filter(ImageFilter.GaussianBlur()).resize((120, 120),Image.LANCZOS)
img2.show()

#---- バイトで標準出力 ----
po = io.BytesIO();
img2.save(po, format='PNG')
sys.stdout.buffer.write(po.getvalue())

