# -*- coding: utf-8 -*-
import psycopg2

from pdfrw import PdfReader
from pdfrw.buildxobj import pagexobj
from pdfrw.toreportlab import makerl
from reportlab.pdfgen import canvas
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase import pdfmetrics

# テンプレート読込
page = PdfReader('C:/work/template2.pdf', decompress=False).pages
pp = pagexobj(page[0])

# フォント指定
fontname_g = "HeiseiKakuGo-W5"
pdfmetrics.registerFont(UnicodeCIDFont(fontname_g))

# 出力先指定
cc = canvas.Canvas("out.pdf")
# フォント→ページセット
cc.setFont(fontname_g, 16)
cc.doForm(makerl(cc, pp))


y_pos = 600

with psycopg2.connect("host=localhost port=5432 dbname=mincdb user=postgres password=admin") as con:
    with con.cursor() as cur:
        cur.execute('SELECT name FROM company')
        for row in cur:
            result = cur.fetchone()
            cname = result[0]
            print(cname)
            print(cname.encode())
            cc.drawString(100, y_pos, cname)
            y_pos += 20

cc.showPage()
cc.save()


