# -*- coding: UTF-8 -*-
import itertools
import math

counter = 0
for s in itertools.permutations(['A','B','C'], r=3):
    print(s)
print("---------------")
for s in itertools.product(['A','B','C','D','E','F','G','H'], repeat=8):
        # print(s)
        counter += 1
print("size = %d" % counter)
# def permutations_count(n, r):
#     return math.factorial(n) // math.factorial(n - r)
# print(permutations_count(3, 3))