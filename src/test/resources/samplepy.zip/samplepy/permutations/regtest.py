# -*- coding: UTF-8 -*-

import regex

p = regex.compile(r'\p{Block=Hiragana}+')
print(p.fullmatch('あん'))

p = regex.compile(r'\p{Block=Hiragana}+')
print(p.fullmatch('あーん'))

p = regex.compile(r'\p{Block=katakana}+')
print(p.fullmatch('アーン'))



p = regex.compile(r'[\p{Script=Han}]')
print(p.findall('漢字あ報道'))
for e in p.findall('漢字報道'):
    print(e)



p = regex.compile(r'\p{Script_Extensions=Han}+')
print(p.fullmatch('〆㊊㈴㈲㈪㈫㈬㈭㈮㈯㈰㈱㈲㈳㈴㈵㈶㈷㈸㈹㈺㈻㈼㈽㈾㈿㉀㉁㉂㉃'))

if p.match('〆'):
    print("Yes")