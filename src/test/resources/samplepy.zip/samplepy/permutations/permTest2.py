# -*- coding: UTF-8 -*-

import itertools

for s in itertools.combinations(['A','B','C'], 2):
    print(s)

for s in itertools.combinations_with_replacement(['A', 'B', 'C'], 3):
    print(s)
print("---------------")
for s in itertools.product(['A','B','C'], repeat=3):
    print(s)
