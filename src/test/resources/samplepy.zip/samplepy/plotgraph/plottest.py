# -*- coding: UTF-8 -*-
import matplotlib.pyplot as plt
import math
import numpy as np



x = np.linspace(0,10,100)
y = x
plt.plot(x,y)

# plt.plot( [3,1,4,1,5,9,2,6,5] )
plt.margins(x=0, y=0)

plt.grid(True)
plt.show()
# plt.savefig('test.png')
