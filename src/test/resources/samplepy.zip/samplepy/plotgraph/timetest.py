# -*- coding: UTF-8 -*-
import datetime
import random
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

# make up some data
x = [datetime.datetime.now() + datetime.timedelta(hours=i) for i in range(12)]
y = [i+random.gauss(0,1) for i,_ in enumerate(x)]

print(x)
print(y)

fig, ax = plt.subplots()

# plot
plt.plot(x, y)
# beautify the x-labels
#plt.gcf().autofmt_xdate()

myFmt = mdates.DateFormatter('%H:%M')
ax.xaxis.set_major_formatter(myFmt)


plt.show()