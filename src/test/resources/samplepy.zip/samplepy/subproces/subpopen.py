# -*- coding: UTF-8 -*-
import subprocess
from subprocess import PIPE

text = 'Hello\n'
print("========================")
# p = subprocess.Popen(['java', '-jar', 'talkdemo.jar', 'A', 'B', 'C'], stdin=PIPE, stdout=PIPE, stderr=PIPE)
p = subprocess.Popen('java -jar talkdemo.jar A B C',  shell=True, stdout=PIPE, stderr=PIPE)
# res = p.communicate(input='C:/Users/yamada/PycharmProjects/ProA/subproces/test.txt\n')
for line in iter(p.stdout.readline, b''):
    print(line.rstrip().decode("sjis"))

(p1out, p1err)  = p.communicate(input=text)
print("========================")
print(p1out)
