# -*- coding: UTF-8 -*-
import subprocess
from subprocess import PIPE

res = subprocess.run(["dir"], shell=True, stdout=PIPE, stderr=PIPE)
print("========================")
print(res.stdout.decode("sjis"))
