# -*- coding: UTF-8 -*-

# 抽象構文木 (Abstract Syntax Tree)  ast のヘルパー関数 literal_eval を使う！

import json
import ast

txt = '{ "a":10, "b":"ＡＢＣ", "c":{ "d":"abc"  } }'
#txt = "{ 'a':10, 'b':'ＡＢＣ' , 'c':{ 'd':'abc'  }}"

dict = json.loads('{ "a":10, "b":"ＡＢＣ", "c":{ "d":"abc"  } }')

print("a = %d " % dict.get('a'))
print("b = %s " % dict.get('b'))
print("c = %s " % dict.get('c'))

dict = ast.literal_eval("{ 'a':10, 'b':'ＡＢＣ' , 'c':{ 'd':'abc' } }")

print("a = %d " % dict.get('a'))
print("b = %s " % dict.get('b'))
print("c = %s " % dict.get('c'))
