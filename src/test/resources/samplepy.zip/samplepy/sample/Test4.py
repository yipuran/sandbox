# -*- coding: UTF-8 -*-
from logger import Logger

logger = Logger()
#logger.warn("■ %s" % "test＿A")

s = 'あ'
print(s.encode('unicode_escape'))