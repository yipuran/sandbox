# -*- coding: utf-8 -*-
import wx
import sys,os

app = wx.App(False) # 新しいアプリケーションを生成．ウィンドウにstdout/stderrをリダイレクトしないこと．
frame = wx.Frame(None, wx.ID_ANY, "Hello World") # フレームはトップレベルウィンドウ
frame.Show(True) # フレームを表示
app.MainLoop()