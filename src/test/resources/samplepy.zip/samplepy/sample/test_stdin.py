# -*- coding: UTF-8 -*-
import codecs
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, portrait
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
import sys

sys.setdefaultencoding('utf-8')


pdfmetrics.registerFont(UnicodeCIDFont('HeiseiKakuGo-W5'))


FILENAME = 'HelloWorld.pdf'

c = canvas.Canvas(FILENAME, pagesize=portrait(A4))
c.setFont('HeiseiKakuGo-W5', 12)
# 真ん中に文字列描画
width, height = A4  # A4用紙のサイズ


def test(list):
    for e in list:
        s = e
        print("===================")
        print(type(e))
        s = e.encode('utf8','surrogateescape')
        print("===================")
        print(type(s))


        c.drawCentredString(width / 2, height / 2, s.decode('utf-8') )

    c.save()


if __name__ == '__main__':
    inlist = []
    try:
        while True:
            inp = input('')
            if inp=='':break
            inlist.append(inp)
    except EOFError:
        pass
    print(inlist)
    print('--------------')
    test(inlist)