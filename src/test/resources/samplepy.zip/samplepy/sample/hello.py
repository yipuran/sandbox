# -*- coding: UTF-8 -*-
import datetime
def helloFunc(m):
    str = "Hello Python : " + m
    print(str)
    sts = "あ"
    res = "helloFunc result = " + sts
    return res.decode("UTF-8")
'''
result = helloFunc("a")
'''
if __name__ == '__main__' :
    print('モジュール名：{}'.format(__name__))
    print("Hello")
    today = datetime.datetime.today()
    print(today)
    yobi = ["月", "火", "水", "木", "金", "土", "日"]
    dispdate = today.strftime("%Y/%m/%d %H:%M:%S") + " ("+ yobi[today.weekday()] + ")"
    print(dispdate)
    print(today.isocalendar())
    weekNumber = today.isocalendar()[1]
    print(weekNumber)
    d = datetime.datetime(2018, 1, 7)
    print(d.isocalendar())
    print("-------------")
    now = datetime.datetime.now()
    print(now.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3])

    a = datetime.strptime('2019-02-26 00:00', '%Y-%m-%d %H:%M')
    print(a)

