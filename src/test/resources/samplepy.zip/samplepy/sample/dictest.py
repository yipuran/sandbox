# -*- coding: UTF-8 -*-

dict = { "a":"aaa 1 bbb", "b":"aaa 2 bbb", "c":"aaa 3 bbb" }

[v for k, v in dict.items() if v == "aaa 2 bbb"]

print(list)


