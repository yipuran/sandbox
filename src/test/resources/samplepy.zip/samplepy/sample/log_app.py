# -*- coding: UTF-8 -*-
import datetime
class logger:
    def __init__(self, callnames):
        self.callnames = callnames
        self.out = open('c:/var/log/test.log', 'a+')
    def debug(self, data):
        time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        print(time + " DEBUG " + data + "\t\t[" + self.callnames + "]", file=self.out)
