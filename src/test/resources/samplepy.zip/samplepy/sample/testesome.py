# -*- coding: UTF-8 -*-
#import logger
from sample import log_app


class Testsome:

    def __init__(self):
        self.log = log_app.logger("Testsome.py")
    def test(self):
        self.log.debug("test = %d" % 1223)
        self.log.debug("s    = %s" % "aaaaa")
        print("--- testsome.py ---")
####################
t = Testsome()
t.test()
