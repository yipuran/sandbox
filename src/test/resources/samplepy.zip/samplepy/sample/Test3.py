# -*- coding: UTF-8 -*-

import logging.config

str = "あ222ああ"


logging.config.fileConfig("logging.ini")

logger = logging.getLogger()
logger.debug("Test3 %s %d " % (str, 21))
logger.info("Test3 %s %d " % (str, 22))
userid = "aa123-03dd2"
logger.debug("user id = %s" % userid)
