# -*- coding: UTF-8 -*-
import json
import codecs

def testJson():
    txt = '{ "name":"あいうA", "flg":"false", "price":10, "item":null }'
    data = json.loads(txt)

    for key, value in data.items():
        print("# %s -- %s" % (key, value))

    print("============")

    with codecs.open("test2.json", 'r', 'utf-8') as f:
        data = json.load(f)
        for key, value in data.items():
            print("# %s -- %s" % (key, value) )

    #encode_json_data = json.dumps(data, ensure_ascii=False, indent=2)
    #print(encode_json_data)

    dict = { "name":"あいうえお" , "flg":False, "price": 22 }
    with codecs.open('test2.json', 'w+', 'utf-8') as fp:
        json.dump(dict, fp, ensure_ascii=False, indent=2)


if __name__ == '__main__' :
    testJson()