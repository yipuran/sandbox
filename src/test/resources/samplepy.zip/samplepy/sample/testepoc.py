# -*- coding: UTF-8 -*-
from datetime import datetime
import time

# def datetime_to_epoch(d):
#     return int(time.mktime(d.timetuple()))

print(datetime.now())

# 現在エポック秒
epoch = int(time.mktime(datetime.now().timetuple()))
print(epoch)

# エポック秒 → datetime
dtime = datetime(*time.localtime(epoch)[:6])
print(dtime)

# 現在エポックミリ秒
epocmili = int(datetime.now().timestamp() * 1000)
print(epocmili)





