# -*- coding: UTF-8 -*-

class Some:
    def __init__(self, name):
        self.__aname = name
    def getName(self):
        return self.__aname
    def add(self, a):
        self.__aname = "%s_%s" %(self.__aname, a)
