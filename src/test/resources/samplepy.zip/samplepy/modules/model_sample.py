# -*- coding: UTF-8 -*-

from some import Some

a = Some('Anc')
print( a.getName() )
a.add("BIG")
print( a.getName() )


