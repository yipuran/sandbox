# -*- coding: UTF-8 -*-
import csv
import codecs

with codecs.open('sample.csv', 'w', 'UTF-8') as f:
    f.write(u'\ufeff')
    cf = csv.writer(f)
    cf.writerow(['A','B','C'])
    cf.writerow(['あ', 'い', 'う' ])
    cf.writerow(['a,a', 'b"b', 0 ])
# 読込み
with codecs.open('sample.csv', 'r', 'utf-8') as f:
    row = [row for row in csv.reader(f)]
    for row in row[1:]:
        print("A = %s  B = %s C = %s" % (row[0], row[1], row[2]) )

with codecs.open('sample2.csv', 'r', 'utf-8') as f:
    row = [row for row in csv.reader(f)]
    for row in row[1:]:
        print("A = %s  B = %s C = %s" % (row[0], row[1], row[2]) )
