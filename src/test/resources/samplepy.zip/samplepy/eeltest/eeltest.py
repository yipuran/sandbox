# -*- coding: UTF-8 -*-
import eel

eel.init("web")
eel.start("hello.html")
