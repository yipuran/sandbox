# -*- coding: UTF-8 -*-

class StdIn:
    def read(self):
        inlist = []
        try:
            while True:
                inp = input('')
                if inp == '': break
                inlist.append(inp)
        except EOFError:
            pass
        return inlist
