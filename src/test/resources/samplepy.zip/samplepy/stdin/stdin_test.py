# -*- coding: utf-8 -*-
#  標準入力テスト




if __name__ == '__main__':
    inlist = []
    try:
        while True:
            inp = input('')
            if inp == '': break
            inlist.append(inp)
    except EOFError:
        pass
    print(inlist)
    print('--------------')
    for s in inlist:
        print(s)


