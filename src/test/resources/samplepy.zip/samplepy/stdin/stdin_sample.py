# -*- coding: UTF-8 -*-
#  stdin_sample.py
import sys
import codecs


#  処理
def sample_func(inlist):
    with codecs.open('log.txt', 'w', 'utf-8') as f:
        for e in inlist:
            # 外から utf-8 でくる場合
            data = e.encode().decode('unicode-escape')
            # 通常
            data = e
            print("data = %s" % data)
            f.write(data)
            f.write("\n")



#######################
if __name__ == '__main__':
    inlist = []
    try:
        while True:
            inp = input('')
            if inp=='':break
            inlist.append(inp)
    except EOFError:
        pass
    # 入力リストで処理
    sample_func(inlist)





