# -*- coding: utf-8 -*-

import sys
import codecs

#sys.stdin = codecs.getreader('utf-8')(sys.stdin)

# str = "あ"
# print(ascii('あ'))
# print("====")
# data = str.encode()
# print(data)
# print( codecs.decode(data, encoding='utf-8') )


if __name__ == '__main__':
    inlist = []
    try:
        while True:
            inp = input('')
            if inp=='':break
            # inp = inp.encode().decode('unicode-escape')
            inp = inp.encode().decode('utf-8')
            inlist.append(inp)
    except EOFError:
        pass

    print('-- input end --')
    for e in inlist:
        print('--------------')
        print(e)
        #s = e.encode('unicode_escape')
        #print("s = %s" % s.decode())
        #t = codecs.decode(s, 'unicode-escape')
        #u = str("%s" % t)
        #print("u = %s" % u)







