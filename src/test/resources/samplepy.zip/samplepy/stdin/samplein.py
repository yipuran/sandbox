# -*- coding: UTF-8 -*-

from stdinput import StdIn

stdin = StdIn()
list = stdin.read()
print(list)

list = stdin.read()
print(list)




