# -*- coding: UTF-8 -*-
import re

print("==== よくある方法 :  re.sub(\"_(.)\", lambda m:m.group(1).upper(), str) ====")
str = "abc_def_ghi_2j"
res = re.sub("_(.)", lambda m:m.group(1).upper(), str)
print("%s → %s" % (str, res))
str = "ABC_DEF_GHI_2J"
res = re.sub("_(.)", lambda m:m.group(1).upper(), str)
print("%s → %s" % (str, res))

print("==== lower()してから、 :  re.sub(\"_(.)\", lambda m:m.group(1).upper(), str.lower()) ====")
res = re.sub("_(.)", lambda m:m.group(1).upper(), str.lower())
print("%s → %s" % (str, res))

# components = str.split('_')
print("==== split capitalize() で : ''.join(x.capitalize() for x in str.split('_')) ==========")
res = ''.join(x.capitalize() for x in str.split('_'))
print("%s → %s" % (str, res))
print("==== split title() で : ''.join(x.title() for x in str.split('_')) ==========")
res = ''.join(x.title() for x in str.split('_'))
print("%s → %s" % (str, res))
#
#
print("====== str.title().replace(\"_\", \"\")　の方法 ======= ")
str = "ABC_DEF_GHI_2J"
res = str.title().replace("_", "")
print("%s → %s" % (str, res))
str = "ABC_DEF_GHI_2J"

def toCamelCase(string, titleCase=False):
    import re
    if titleCase:
        return ''.join(x.title() for x in string.split('_'))
    else:
        return re.sub("_(.)", lambda m:m.group(1).upper(), string.lower())

print("==== toCamelCase(str) ====")
res = toCamelCase(str)
print("%s → %s" % (str, res))

print("==== toCamelCase(str, True) ====")
res = toCamelCase(str, True)
print("%s → %s" % (str, res))

print("============= ")
# str = "ABC_DEF_GHI_2J"
str = "abc_def_ghi_2j"
res = str.title().replace("_", "")
print("%s → %s" % (str, res))


