# -*- coding: UTF-8 -*-
str = "ABC_DEF_GHI_2J"
res = str.title().replace("_", "")
print("%s → %s" % (str, res))