# -*- coding: UTF-8 -*-
import re

def toCamelCase(string, titleCase=False):
    import re
    if titleCase:
        return ''.join(x.title() for x in string.split('_'))
    else:
        return re.sub("_(.)", lambda m:m.group(1).upper(), string.lower())
def toSnakeCase(string, upper=False):
    import re
    #return re.sub("([A-Z])",lambda x:"_" + x.group(1), string)
    return re.sub("(.[A-Z])",lambda x:x.group(1)[0] + "_" +x.group(1)[1], string).lower()
    #s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', string)
    #return re.sub('([a-z0-9])([A-Z])', r'\1_\2', re.sub('(.)([A-Z][a-z]+)', r'\1_\2', string)).lower()

str = "ABC_DEF_GHI_2J"

print("==== toCamelCase(str) ====")
res = toCamelCase(str)
print("%s → %s" % (str, res))

print("==== toCamelCase(str, True) ====")
res = toCamelCase(str, True)
print("%s → %s" % (str, res))

s = toSnakeCase(res)
print(s)