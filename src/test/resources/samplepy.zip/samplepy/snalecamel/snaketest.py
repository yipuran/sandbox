# -*- coding: UTF-8 -*-
import re
str = "abcDefGhi2j"
str2 = "AbcDefGhi2j"

res = re.sub("([A-Z])",lambda x:"_" + x.group(1), str).lower()
print("%s → %s" % (str , res))
res2 = re.sub("([A-Z])",lambda x:"_" + x.group(1), str2).lower()
print("%s → %s" % (str2 , res2))
print("------------")
res = re.sub("(.[A-Z])",lambda x:x.group(1)[0] + "_" +x.group(1)[1], str).lower()
print("%s → %s" % (str , res))
res2 = re.sub("(.[A-Z])",lambda x:x.group(1)[0] + "_" +x.group(1)[1], str2).lower()
print("%s → %s" % (str2 , res2))
print("------------")
res = re.sub('([a-z0-9])([A-Z])', r'\1_\2', re.sub('(.)([A-Z][a-z]+)', r'\1_\2', str)).lower()
print("%s → %s" % (str , res))
res2 = re.sub('([a-z0-9])([A-Z])', r'\1_\2', re.sub('(.)([A-Z][a-z]+)', r'\1_\2', str2)).lower()
print("%s → %s" % (str2 , res2))
print("------------")

def toSnakeCase(string, upper=False):
    import re
    if upper:
        return re.sub("(.[A-Z])",
                      lambda x: x.group(1)[0] + "_" + x.group(1)[1],
                      string).lower().upper()
    else:
        return re.sub("(.[A-Z])",
                      lambda x:x.group(1)[0] + "_" +x.group(1)[1],
                      string).lower()

res = toSnakeCase(str2, True)
print("%s → %s" % (str2 , res))