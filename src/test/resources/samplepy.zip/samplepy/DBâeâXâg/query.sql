SELECT id
, CASE WHEN name = 'A' THEN point END AS A
, CASE WHEN name = 'B' THEN point END AS B
, CASE WHEN name = 'C' THEN point END AS C
, CASE WHEN name NOT IN ('A','B','C') THEN point END DD
FROM sample


SELECT SUM(CASE WHEN name = 'A' THEN point END) AS A
, SUM(CASE WHEN name = 'B' THEN point END) AS B
, SUM(CASE WHEN name = 'C' THEN point END) AS C
, SUM(CASE WHEN name NOT IN ('A','B','C') THEN point END) DD
FROM sample


SELECT name FROM sample GROUP BY name ORDER BY name ASC

