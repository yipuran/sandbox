# -*- coding: UTF-8 -*-
import codecs
from mysqlConnector import MySQLConnector

with MySQLConnector(host='localhost', port=3308, user='uranus', password='zaq2013', database='test') as con:
    cur = con.cursor()
    cur.execute('DROP TABLE IF EXISTS test.sample')
    # DROP TABLE と CREATE TABLE １文ずつ実行
    with codecs.open('tablecreate.sql', 'r', 'utf-8') as fp:
        createsql = fp.read()
        print(createsql)
        cur.execute(createsql)
print("====== finish ======")
