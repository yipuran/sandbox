# -*- coding: UTF-8 -*-

from mysqlConnector import MySQLConnector

with MySQLConnector(host='localhost', port=3308, user='uranus', password='zaq2013', database='test') as con:
    cur = con.cursor()
    cur.execute("SELECT name FROM sample GROUP BY name ORDER BY name ASC")
    queryary = []
    sumqueryary = []
    for row in cur.fetchall():
        queryary.append("CASE WHEN name = '%s' THEN point END AS %s" % (row[0], row[0]))
        sumqueryary.append("SUM(CASE WHEN name = '%s' THEN point END) AS %s" % (row[0], row[0]))
    querystr = "SELECT id, %s FROM sample" %  ",".join(queryary)
    print(querystr)
    cur.execute(querystr)
    for row in cur.fetchall():
        print(row)
    print("-------------------------------------")
    querystr = "SELECT %s FROM sample" %  ",".join(sumqueryary)
    print(querystr)
    cur.execute(querystr)
    for row in cur.fetchall():
        print(row)


