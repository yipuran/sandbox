# -*- coding: UTF-8 -*-
import csv
import codecs
from mysqlConnector import MySQLConnector

with MySQLConnector(host='localhost', port=3308, user='uranus', password='zaq2013', database='test') as con:
    cur = con.cursor()
    cur.execute('TRUNCATE TABLE sample')
    # ＣＳＶ読込み
    with codecs.open('sampledata.csv', 'r', 'utf-8') as fp:
        reader = csv.reader(fp)
        row = [row for row in reader]
        for row in row[1:]:
            print("name=%s  point = %d" % (row[0], int(row[1])) )
            stmt = "INSERT INTO sample (name, point)VALUES('%s', %d)" % (row[0], int(row[1]))
            cur.execute(stmt)
        cur.execute("commit")
    print("------ insert complete -----")
    cur.execute("SELECT id, name, point FROM sample")
    tables = cur.fetchall()
    for row in tables:
        print("id = %d  name=%s  point = %d" % (int(row[0]), row[1], int(row[2])))
