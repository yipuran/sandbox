# -*- coding: UTF-8 -*-
class MySQLConnector:
    def __init__(self, host, port, user, password, database):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.database = database
    def __enter__(self):
        import mysql.connector
        self.connect = mysql.connector.connect(
            host=self.host,
            port=self.port,
            user=self.user,
            password=self.password,
            database=self.database,
            charset="utf8")
        return self.connect
    def __exit__(self, exception_type, exception_value, traceback):
        self.connect.close()