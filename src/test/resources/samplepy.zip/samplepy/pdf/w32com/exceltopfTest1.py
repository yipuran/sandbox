# -*- coding: UTF-8 -*-
import win32com.client
# from pywintypes import com_error
# pip install pywin32
#  https://sites.google.com/site/pythoncasestudy/home/pywin32kara-comwo-tsuka-tsu-te-excelwo-sousa-suru-houhou
# win32com.client で、 Excel.Application を起動
# VBA https://docs.microsoft.com/ja-jp/office/vba/api/excel.workbook.exportasfixedformat の ActiveSheet.ExportAsFixedFormat を実行する
#  ActiveSheet.ExportAsFixedFormat(1, で、xps ビュー形式ファイルに、
#  VBA  ActiveSheet.ExportAsFixedFormat には、上書きすることができない、VBAとしては、別途、確認ダイアログを実行する必要がある。


excel = win32com.client.Dispatch("Excel.Application")

# Excel は表示させない→ False
excel.Visible = False

try:
    wb = excel.Workbooks.Open("C:/Users/yamada/PycharmProjects/ProA/pdf/w32com/toc_data.xlsx")
    wb.Worksheets("TOCmysql").Activate()
    wb.ActiveSheet.ExportAsFixedFormat(0, "C:/Users/yamada/PycharmProjects/ProA/pdf/w32com/res.pdf" )
except:
    print('失敗しました')
else:
    print('成功しました')
finally:
    wb.Close()
    excel.Quit()

