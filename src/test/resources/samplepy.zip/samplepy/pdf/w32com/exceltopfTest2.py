# -*- coding: UTF-8 -*-
import win32com.client

excel = win32com.client.Dispatch("Excel.Application")
excel.Visible = False

try:
    wb = excel.Workbooks.Open("C:/Users/yamada/PycharmProjects/ProA/pdf/w32com/toc_設計data.xlsx")
    wb.Worksheets("TOCmysql").Activate()
    wb.ActiveSheet.ExportAsFixedFormat(0, "C:/Users/yamada/PycharmProjects/ProA/pdf/w32com/res.pdf" )
except:
    print('失敗しました')
else:
    print('成功しました')
finally:
    wb.Close()
    excel.Quit()

