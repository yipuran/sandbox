# -*- coding: utf-8 -*-

import sys
from pdfrw import PdfReader
from pdfrw.buildxobj import pagexobj
from pdfrw.toreportlab import makerl
from reportlab.pdfgen import canvas
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase import pdfmetrics
from PIL import Image
import io
from base64 import b64encode

cc = canvas.Canvas('c:/work/result.pdf')
fontname_g = "HeiseiKakuGo-W5"
pdfmetrics.registerFont(UnicodeCIDFont(fontname_g))
#cc.setFont(fontname_g, 16)

#############
page = PdfReader('template2.pdf', decompress=False).pages
pp = pagexobj(page[0])


cc.setFont(fontname_g, 12)
cc.doForm(makerl(cc, pp))
cc.drawString(20, 800, "テスト abcdef 1234567890")

cc.showPage()
# 改ページとして、2 回　showPage() を走らせる
cc.setFont(fontname_g, 16)
cc.doForm(makerl(cc, pp))
cc.drawString(100, 600, "テスト ABCDEF 1234567890")

#with Image.open('c:/work/berry.jpg') as image:
#    cc.drawInlineImage(image, 100, 620, 255, 166)

cc.showPage()
cc.save()


# 標準出力　エンコードを強制的に utf-8
#sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding=sys.stdout.encoding,
#                              errors='backslashreplace',
#                              line_buffering=sys.stdout.line_buffering)
#sys.stdin = io.TextIOWrapper(sys.stdin.buffer, encoding='utf-8')
#sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
#with open('c:/work/result.pdf', 'rb') as f:
#    print( b64encode(f.read()).decode(encoding='utf-8') )



