# -*- coding: utf-8 -*-
from PyPDF3 import PdfFileWriter, PdfFileReader
import io
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase import pdfmetrics
import sys

pdfmetrics.registerFont(UnicodeCIDFont('HeiseiKakuGo-W5'))
pdfmetrics.registerFont(UnicodeCIDFont('Century'))

packet = io.BytesIO()
# Create a new PDF with Reportlab
can = canvas.Canvas(packet, pagesize=A4)
can.setFont('HeiseiKakuGo-W5', 24)
can.drawString(10, 100, "Hello world")
can.showPage()
can.save()

packet.seek(0)
new_pdf = PdfFileReader(packet)
# Read your existing PDF
existing_pdf = PdfFileReader(open("C:/Users/yamada/PycharmProjects/Labo/pdf/aran/blank.pdf", "rb"))
output = PdfFileWriter()
# Add the "watermark" (which is the new pdf) on the existing page
page = existing_pdf.getPage(0)
page.mergePage(new_pdf.getPage(0))
output.addPage(page)

po = io.BytesIO()
output.write(po)
dt = po.getvalue()
sys.stdout.buffer.write(dt)