# -*- coding: UTF-8 -*-
from pdfrw import PdfReader
from pdfrw.buildxobj import pagexobj
from pdfrw.toreportlab import makerl

from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase import pdfmetrics
from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
import reportlab.rl_config

from pagenumCanvas import PageNumCanvas

import webbrowser

pdfmetrics.registerFont(UnicodeCIDFont('HeiseiKakuGo-W5'))
center_w = reportlab.rl_config.defaultPageSize[0] / 2.0
center_h = reportlab.rl_config.defaultPageSize[1] / 2.0

# テンプレート読込
page = PdfReader('temp3.pdf', decompress=False).pages
pp = pagexobj(page[0])

def laterPages(canvas, doc):
    # サンプルなので無理やりループする。
    for i in range(4):
        if i > 0: canvas.showPage()
        canvas.doForm(makerl(canvas, pp))
        canvas.setFont("HeiseiKakuGo-W5", 9)
        canvas.saveState()
        #----- 目的の出力 -----
        canvas.drawCentredString(center_w, center_h, "あいう テスト")
        #
        canvas.restoreState()
def run():
    outfile = 'res.pdf'
    doc = SimpleDocTemplate(outfile)
    doc.build([Paragraph("", getSampleStyleSheet()['Normal'])]
              , onFirstPage=laterPages
              , onLaterPages=laterPages
              , canvasmaker=PageNumCanvas)
    # 結果をブラウザ表示
    webbrowser.open(outfile)
run()
