# -*- coding: UTF-8 -*-

from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase import pdfmetrics
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
import reportlab.rl_config
import webbrowser

pdfmetrics.registerFont(UnicodeCIDFont('HeiseiKakuGo-W5'))

styles = getSampleStyleSheet()
my_style = styles['Normal']
my_style.name = 'mystyle'
my_style.fontName = 'HeiseiKakuGo-W5'

'''
def firstPage(canvas, doc):
    canvas.saveState()
    canvas.setFont('HeiseiKakuGo-W5',18)
    canvas.drawCentredString(reportlab.rl_config.defaultPageSize[0]/2.0, reportlab.rl_config.defaultPageSize[1]-70, 'サンプル')
    canvas.setFont('HeiseiKakuGo-W5',9)
    #canvas.drawString(inch, 0.75*inch, u'これは "%s" の表紙なんだぜ？' % pageinfo)
    canvas.restoreState()
'''
def laterPages(canvas, doc):
    canvas.saveState()
    canvas.setFont("HeiseiKakuGo-W5", 9)
    canvas.restoreState()

def go():
    outfile = 'res.pdf'
    doc = SimpleDocTemplate(outfile)
    Story = []
    style = my_style
    for i in range(5):
        bogustext = (" (段落番号は %s) " % (i + 1)) * 120
        p = Paragraph(bogustext, style)
        Story.append(p)
        Story.append(Spacer(1, 0.2*inch))
    #doc.build(Story, onFirstPage=firstPage, onLaterPages=laterPages)
    doc.build(Story, onLaterPages=laterPages)
    # 結果をブラウザ表示
    webbrowser.open(outfile)
go()
