# -*- coding: utf-8 -*-

from pdfrw import PdfReader
from pdfrw.buildxobj import pagexobj
from pdfrw.toreportlab import makerl
import reportlab.rl_config

class LaterPages:
    global page_template
    center_w = reportlab.rl_config.defaultPageSize[0] / 2.0
    center_h = reportlab.rl_config.defaultPageSize[1] / 2.0

    def __init__(self, template):
        temp_page = PdfReader(template, decompress=False).pages
        LaterPages.page_template = pagexobj(temp_page[0])

    def laterpages(self, canvas, doc):
        # サンプルなので無理やりループする。
        for i in range(4):
            if i > 0: canvas.showPage()
            canvas.doForm(makerl(canvas, LaterPages.page_template))
            canvas.setFont("HeiseiKakuGo-W5", 9)
            canvas.saveState()
            #----- 目的の出力 -----
            canvas.drawCentredString(LaterPages.center_w, LaterPages.center_h, "あいう テスト")
            #
            canvas.restoreState()
