# -*- coding: UTF-8 -*-

from pdfrw import PdfReader
from pdfrw.buildxobj import pagexobj
from pdfrw.toreportlab import makerl
from reportlab.pdfgen import canvas
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase import pdfmetrics
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.lib.units import mm
import reportlab.rl_config
import webbrowser

pdfmetrics.registerFont(UnicodeCIDFont('HeiseiKakuGo-W5'))
center_w = reportlab.rl_config.defaultPageSize[0] / 2.0
center_h = reportlab.rl_config.defaultPageSize[1] / 2.0
########################################################################
# http://www.blog.pythonlibrary.org/2013/08/12/reportlab-how-to-add-page-numbers/
class PageNumCanvas(canvas.Canvas):
    """
    http://code.activestate.com/recipes/546511-page-x-of-y-with-reportlab/
    http://code.activestate.com/recipes/576832/
    """
    def __init__(self, *args, **kwargs):
        canvas.Canvas.__init__(self, *args, **kwargs)
        self.pages = []
    def showPage(self):
        self.pages.append(dict(self.__dict__))
        self._startPage()
    def save(self):
        page_count = len(self.pages)
        for page in self.pages:
            self.__dict__.update(page)
            self.draw_page_number(page_count)
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)
    def draw_page_number(self, page_count):
        page = "Page %s of %s" % (self._pageNumber, page_count)
        self.setFont("Helvetica", 10)
        self.drawRightString(195 * mm, 272 * mm, page)
##################

# テンプレート読込
page = PdfReader('temp3.pdf', decompress=False).pages
pp = pagexobj(page[0])

def laterPages(canvas, doc):
    for i in range(4):
        if i > 0: canvas.showPage()
        canvas.doForm(makerl(canvas, pp))
        canvas.saveState()
        canvas.setFont("HeiseiKakuGo-W5", 9)
        #----- 目的の出力 -----
        canvas.drawCentredString(center_w, center_h, "あいう テスト")
        #
        canvas.restoreState()
def run():
    outfile = 'res.pdf'
    doc = SimpleDocTemplate(outfile)
    doc.build([Paragraph("", getSampleStyleSheet()['Normal'])], onFirstPage=laterPages, onLaterPages=laterPages, canvasmaker=PageNumCanvas)
    # 結果をブラウザ表示
    webbrowser.open(outfile)
run()
