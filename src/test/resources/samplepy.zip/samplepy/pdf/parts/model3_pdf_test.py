# -*- coding: UTF-8 -*-

import sys
import io
from pdfrw import PdfReader
from pdfrw.buildxobj import pagexobj
from pdfrw.toreportlab import makerl

import reportlab.rl_config
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase import pdfmetrics
from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
from PyPDF3 import PdfFileWriter, PdfFileReader

from pagenumCanvas import PageNumCanvas
from laterspage import LaterPages

#pdfmetrics.registerFont(UnicodeCIDFont('HeiseiKakuGo-W5'))

#center_w = reportlab.rl_config.defaultPageSize[0] / 2.0
#center_h = reportlab.rl_config.defaultPageSize[1] / 2.0

# テンプレート読込
#temp_page = PdfReader('C:/Users/yamada/PycharmProjects/Labo/pdf/parts/temp3.pdf', decompress=False).pages
#pp = pagexobj(temp_page[0])

'''
def laterPages(canvas, doc):
    # サンプルなので無理やりループする。
    for i in range(4):
        if i > 0: canvas.showPage()
        canvas.doForm(makerl(canvas, pp))
        canvas.setFont("HeiseiKakuGo-W5", 9)
        canvas.saveState()
        #----- 目的の出力 -----
        canvas.drawCentredString(center_w, center_h, "あいう テスト")
        #
        canvas.restoreState()
'''
def run():
    pdfmetrics.registerFont(UnicodeCIDFont('HeiseiKakuGo-W5'))
    lp = LaterPages('temp3.pdf')

    packet = io.BytesIO()
    doc = SimpleDocTemplate(packet)
    doc.build([Paragraph("", getSampleStyleSheet()['Normal'])]
              , onFirstPage=lp.laterpages
              , onLaterPages=lp.laterpages
              , canvasmaker=PageNumCanvas)
    new_pdf = PdfFileReader(packet)
    #print( new_pdf.getNumPages() )
    output = PdfFileWriter()
    for i in range(new_pdf.getNumPages()):
        page = new_pdf.getPage(i)
        output.addPage(page)
    po = io.BytesIO()
    output.write(po)
    dt = po.getvalue()
    sys.stdout.buffer.write(dt)
run()
