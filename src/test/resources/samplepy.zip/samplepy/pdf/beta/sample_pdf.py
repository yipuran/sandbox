# -*- coding: utf-8 -*-

import sys
import io
from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
from PyPDF3 import PdfFileWriter, PdfFileReader

from pagenumCanvas import PageNumCanvas
from samplepage_pdf import SamplePages

import webbrowser
import os

# PDF 作成
def create(template, inputlist):
    # samplepage 生成インスタンス、テンプレートと入力リストを渡す。
    sample = SamplePages(template, inputlist)

    packet = io.BytesIO()
    doc = SimpleDocTemplate(packet)
    doc.build([Paragraph("", getSampleStyleSheet()['Normal'])]
              , onFirstPage=sample.page
              , onLaterPages=sample.page
              , canvasmaker=PageNumCanvas)

    new_pdf = PdfFileReader(packet)

    output = PdfFileWriter()
    for i in range(new_pdf.getNumPages()):
        output.addPage(new_pdf.getPage(i))
    po = io.BytesIO()
    output.write(po)
    sys.stdout.buffer.write(po.getvalue())

    if __name__ != '__main__':
        outputStream = open('temp.pdf', 'wb')
        output.write(outputStream)
        outputStream.close()
        webbrowser.open('temp.pdf')


#########################
if __name__ == '__main__':
    argv = sys.argv
    argvlen = len(argv)
    if argvlen != 2:
        sys.stderr.write('Error: argument [1]=template file required!')
        exit(1)
    else:
        inlist = []
        try:
            while True:
                inp = input('')
                if inp == '': break
                inlist.append(inp)
        except EOFError:
            pass
        # 文字フォントセット宣言
        #pdfmetrics.registerFont(UnicodeCIDFont('HeiseiKakuGo-W5'))

        # PDF作成実行
        create(argv[1], inlist)
        exit(0)
