# -*- coding: utf-8 -*-

import sys
import sample_pdf


argv = sys.argv
argvlen = len(argv)
if argvlen != 2:
    sys.stderr.write('Error: argument [1]=template file required!')
    exit(1)
else:
    inlist = []
    try:
        while True:
            inp = input('')
            if inp == '': break
            inlist.append(inp)
    except EOFError:
        pass
    # 文字フォントセット宣言
    #pdfmetrics.registerFont(UnicodeCIDFont('HeiseiKakuGo-W5'))

    # PDF作成実行
    sample_pdf.create(argv[1], inlist)
    exit(0)