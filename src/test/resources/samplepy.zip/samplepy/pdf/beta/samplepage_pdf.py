# -*- coding: utf-8 -*-
# samplepage_pdf.py : sample_pdf.py で使用
#
from page_pdf import Pdfpage
from pdfrw import PdfReader
from pdfrw.buildxobj import pagexobj
from pdfrw.toreportlab import makerl
import reportlab.rl_config

class SamplePages(Pdfpage):
    global page_template
    global inlist
    center_w = reportlab.rl_config.defaultPageSize[0] / 2.0
    center_h = reportlab.rl_config.defaultPageSize[1] / 2.0

    def __init__(self, template, inputlist):
        super().__init__()
        # テンプレート読込
        temp_page = PdfReader(template, decompress=False).pages
        SamplePages.page_template = pagexobj(temp_page[0])

        # 入力リスト取得 → global inlist
        SamplePages.inlist = inputlist

    def page(self, canvas, doc):
        # サンプルなので無理やりループする。
        for i in range(4):
            if i > 0: canvas.showPage()
            canvas.doForm(makerl(canvas, SamplePages.page_template))
            canvas.setFont(super().HeiseiKakugoW5, 9)
            canvas.saveState()
            # ----- 目的の canvas 出力 -----
            canvas.drawCentredString(SamplePages.center_w, SamplePages.center_h, "あいう テスト")
            h = 400
            for item in SamplePages.inlist:
                canvas.drawCentredString(SamplePages.center_w, h, item.encode().decode('unicode-escape') )
                h -= 20
            # ------------------------------
            canvas.restoreState()


