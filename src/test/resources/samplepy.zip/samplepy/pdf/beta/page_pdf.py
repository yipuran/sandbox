# -*- coding: utf-8 -*-

from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase import pdfmetrics


class Pdfpage():
    global HeiseiKakugoW5
    def __init__(self):
        Pdfpage.HeiseiKakugoW5 = 'HeiseiKakuGo-W5'
        # 文字フォントセット宣言
        pdfmetrics.registerFont(UnicodeCIDFont('HeiseiKakuGo-W5'))

