# -*- coding: UTF-8 -*-

import sys
import io
import codecs
from pdfrw import PdfReader
from pdfrw.buildxobj import pagexobj
from pdfrw.toreportlab import makerl
from reportlab.pdfgen import canvas
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase import pdfmetrics

# ネスト線を繋ぐためのディクショナリ　 key = x , value = y
nest_dict = {}
# PDF ツリー作成
def create(template, resultfile, list):
    # テンプレート読込
    page = PdfReader(template, decompress=False).pages
    pp = pagexobj(page[0])
    # フォント指定
    fontname_g = "HeiseiKakuGo-W5"
    pdfmetrics.registerFont(UnicodeCIDFont(fontname_g))
    # 出力先指定
    cc = canvas.Canvas(resultfile)
    # フォント→ページセット
    cc.setFont(fontname_g, 12)
    cc.doForm(makerl(cc, pp))
    # font-size:12 → 1page 56 行
    row_count = 0
    y_pos = 800
    prev_nest = 0
    cc.drawString(500, 820, "Page %d" % cc.getPageNumber())
    for e in list:
        d = e.split("%")
        nest = int(d[0])
        x_pos = 40 + (12 * nest)
        if int(d[0]) > 0:
            x_pos += (14 * nest)
        # 名称書込み
        cc.drawString(x_pos, y_pos, d[2].encode().decode('unicode-escape') )
        # セル borser書込み
        cell_border(cc, y_pos, nest, d[1], prev_nest)
        # 前の行の nest
        prev_nest = nest
        #--------------------------------------------
        y_pos -= 16
        row_count += 1
        if y_pos < 40:
            #===== 改ページ処理 ====================
            # ブランチ線の引き継ぎ
            xlist = []
            for key, value in nest_dict.items():
                cc.line(key, value, key, 40)
                xlist.append(key)
            nest_dict.clear()
            for nx in xlist:
                nest_dict[nx] = 820
            # PDF Canvas 生成
            cc.showPage()
            cc.doForm(makerl(cc, pp))
            cc.setFont(fontname_g, 12)
            y_pos = 800
            row_count = 0
            cc.drawString(500, 820, "Page %d" % cc.getPageNumber() )
    cc.showPage()
    cc.save()
    return
# 行 ブランチ線の書込み
def cell_border(c, y, nest, tail, prev_nest):
    x1 = nest * 24 + 28
    x2 = x1 + 10
    # 横
    c.line(x1, y+4, x2, y+4)
    # 縦
    y1 = y + 4 if tail=='true' else y - 2
    c.line(x1, y1, x1, y+14)
    # up or down?
    if prev_nest > nest:
        # up
        if x1 in nest_dict:
            c.line(x1, nest_dict.get(x1), x1, y + 14)
            del nest_dict[x1]
    elif prev_nest==nest:
        if x1 in nest_dict:
            del nest_dict[x1]
    if tail == 'false':
        nest_dict[x1] = y1
#########################
if __name__ == '__main__':
    argv = sys.argv
    argvlen = len(argv)
    if argvlen != 3:
        sys.stderr.write('Error: argument [1]=template file  [2]=out file  required!')
        exit(1)
    else:
        inlist = []
        try:
            while True:
                inp = input('')
                if inp == '': break
                inlist.append(inp)
        except EOFError:
            pass
        print("=======================")
        print("template = %s" % argv[1])
        print("out = %s" % argv[2])
        # PDF作成実行
        create(argv[1], argv[2], inlist)
        print("writed !")
        exit(0)
