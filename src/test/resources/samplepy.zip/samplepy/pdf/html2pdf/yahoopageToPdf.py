# -*- coding: UTF-8 -*-
import pdfkit

options = {
    'page-size': 'A4',
    'orientation': 'Portrait',
    'margin-top': '0.4in',
    'margin-right': '0.4in',
    'margin-bottom': '0.4in',
    'margin-left': '0.4in',
    'encoding': "UTF-8",
    'no-outline': None
}

pdf = pdfkit.from_url("https://www.yahoo.co.jp/", "out.pdf", options=options)

