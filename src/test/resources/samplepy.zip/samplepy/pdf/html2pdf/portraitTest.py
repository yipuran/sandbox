# -*- coding: UTF-8 -*-
# https://pypi.org/project/pdfkit/
#  https://wkhtmltopdf.org/usage/wkhtmltopdf.txt
import pdfkit

options = {
    'page-size': 'A4',
    'orientation': 'Portrait',
    'margin-top': '0.4in',
    'margin-right': '0.4in',
    'margin-bottom': '0.4in',
    'margin-left': '0.4in',
    'encoding': "UTF-8",
    'no-outline': None
}
pdfkit.from_file("portrait.html", "out_port.pdf", options=options)