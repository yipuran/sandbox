# -*- coding: UTF-8 -*-
# WebPageToPdf.py
#  standard input [0] = url,  [1] =page-size , [2] = orientation: 'Portrait' or 'Landscape'
import sys
import pdfkit

def pageToPdf(url, pagesize='A4', orientation='Portrait'):
    options = {
        'page-size': pagesize,
        'orientation': orientation,
        'margin-top': '0.4in',
        'margin-right': '0.4in',
        'margin-bottom': '0.4in',
        'margin-left': '0.4in',
        'encoding': "UTF-8",
        'no-outline': None
    }
    pdf = pdfkit.from_url(url, False, options=options)
    sys.stdout.buffer.write(pdf)

#########################
inlist = []
try:
    while True:
        inp = input('')
        if inp == '': break
        inlist.append(inp)
except EOFError:
    pass
if inlist.__len__()==2:
    pageToPdf(inlist[0], inlist[1])
elif inlist.__len__()==3:
    pageToPdf(inlist[0], inlist[1], inlist[2])
else:
    pageToPdf(inlist[0])
