# -*- coding: UTF-8 -*-
import pdfkit

options = {
    'page-size': 'A4',
    'orientation': 'Portrait',
    'margin-top': '0.4in',
    'margin-right': '0.4in',
    'margin-bottom': '0.4in',
    'margin-left': '0.4in',
    'encoding': "UTF-8",
    'no-outline': None
}
# pdfkit.from_file("sample.html", "out.pdf", options=options)
# pdfkit.from_url('http://localhost:8080/LaboWeb/', 'out.pdf', options=options)
pdfkit.from_url('http://localhost:8080/LaboWeb/shareimage', 'out.pdf', options=options)
# pdf = pdfkit.from_url('http://localhost:8080/LaboWeb/', False, options=options)
# pdf = pdfkit.from_url('http://localhost:8080/LaboWeb/wicket/bookmarkable/org.labo.asset.page.shards.ShardmountImageSamplePage', False, options=options)
# print(pdf)