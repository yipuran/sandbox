# -*- coding: UTF-8 -*-
import sys
import pdfkit

def pageToPdf(url, orientation='Portrait'):
    options = {
        'page-size': 'A4',
        'orientation': orientation,
        'margin-top': '0.4in',
        'margin-right': '0.4in',
        'margin-bottom': '0.4in',
        'margin-left': '0.4in',
        'encoding': "UTF-8",
        'no-outline': None
    }
    pdf = pdfkit.from_url(url, False)
    sys.stdout.buffer.write(pdf)
#########################
inlist = []
try:
    while True:
        inp = input('')
        if inp == '': break
        inlist.append(inp)
except EOFError:
    pass
if inlist.__len__()==2:
    pageToPdf(inlist[0], inlist[1])
elif inlist.__len__()==3:
    pageToPdf(inlist[0])
else:
    print("")

