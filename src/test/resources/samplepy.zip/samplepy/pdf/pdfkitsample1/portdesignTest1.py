# -*- coding: UTF-8 -*-
import pdfkit

options = {
    'page-size': 'A4',
    'orientation': 'Portrait',
    'margin-top': '0.4in',
    'margin-right': '0.4in',
    'margin-bottom': '0.4in',
    'margin-left': '0.4in',
    'encoding': "UTF-8",
    'no-outline': None,
    # '--header-html': 'header.html'
    'header-left': '[webpage]',
    'header-center': 'サンプル',
    'header-right': 'Page  [page]  of  [toPage]',

    'javascript-delay': 3000
}
pdfkit.from_file("sample.html", "out.pdf", options=options)
