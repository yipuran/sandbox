# -*- coding: utf-8 -*-
#  テストPDF
#
import sys
import io
from pdfrw import PdfReader
from pdfrw.buildxobj import pagexobj
from pdfrw.toreportlab import makerl
from reportlab.pdfgen import canvas
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase import pdfmetrics
from PIL import Image
import codecs

# 標準出力で　<_io.TextIOWrapper name='<stdout>' mode='w' encoding='cp932'>　を起こさないようにする
#sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding=sys.stdout.encoding, errors="replace")

# PDF作成
def create(template, resultfile, list):
    # テンプレート読込
    page = PdfReader(template, decompress=False).pages
    pp = pagexobj(page[0])
    # フォント指定
    fontname_g = "HeiseiKakuGo-W5"
    pdfmetrics.registerFont(UnicodeCIDFont(fontname_g))
    # 出力先指定
    cc = canvas.Canvas(resultfile)
    # フォント→ページセット
    cc.setFont(fontname_g, 16)
    cc.doForm(makerl(cc, pp))

    y_pos = 700
    for e in list:
        print("type = %s" % type(e))
        print(ascii(e))
        #cc.drawString(0, y_pos, e)
        cc.drawString(0, y_pos, e.encode().decode('unicode-escape'))
        y_pos += 20

    cc.showPage()
    cc.save()
    return

#########################
if __name__ == '__main__':
    argv = sys.argv
    argvlen = len(argv)
    if argvlen != 3:
        sys.stderr.write('Error: argument [1]=template file  [2]=out file  required!')
        exit(1)
    else:
        inlist = []
        try:
            while True:
                inp = input('')
                if inp == '': break
                inlist.append(inp)
        except EOFError:
            pass
        print("=======================")
        print("template = %s" % argv[1])
        print("out = %s" % argv[2])
        # PDF作成実行
        create(argv[1], argv[2], inlist)

        print("writed !")
        exit(0)