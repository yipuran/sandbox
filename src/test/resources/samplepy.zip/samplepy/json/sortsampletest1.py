# -*- coding: UTF-8 -*-
import json

with open('data.json', 'r', encoding='utf-8') as f:
    print(f)
    # JSONファイル→辞書
    data = json.load(f)
    print(data)
    # data['records'] = sorted(data['records'], key=lambda k: k['point'], reverse=True)
    # data['records'] = sorted(data['records'], key=lambda k: k['item'], reverse=False)
    # data['records'] = sorted(data['records'], key=lambda k: k['date'], reverse=False)
    data['records'] = sorted(data['records'], key=lambda k:  '' if k['memo']==None else k['memo'], reverse=False)
    str = json.dumps(data, indent=4, skipkeys=True, ensure_ascii=False)
    print(str)

