# -*- coding: UTF-8 -*-
import json

with open('sample.json', 'r') as f:
    # JSONファイル→辞書
    dict = json.load(f)
    # str = json.dumps(dict, indent=4)
    str = json.dumps(dict, indent=4, skipkeys=True)
    print(str)
    # 書込み
    with open('test.json', 'w') as fw:
        json.dump(dict, fw, indent=4)

