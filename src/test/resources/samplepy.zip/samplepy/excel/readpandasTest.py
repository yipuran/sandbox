# -*- coding: UTF-8 -*-

import pandas as pd

sheet = pd.read_excel('sample.xlsx', sheet_name='sheet1', skiprows=1)
print(sheet)
