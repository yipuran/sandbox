# -*- coding: UTF-8 -*-
import openpyxl
from datetime import datetime

# datetime.strptime -> strptime
strptime = datetime.strptime

wb = openpyxl.load_workbook("c:/work/LINEWORKS登録台帳 20190220.xlsx")
sheet = wb.get_sheet_by_name('WorksEnterprise Contact')
dtstr = sheet.cell(2, 15).value
print("%s" % dtstr)
dtime = strptime(sheet.cell(2, 15).value, '%Y.%m.%d(%H:%M:%S)')
print(dtime)
wb.close()