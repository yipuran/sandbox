# -*- coding: UTF-8 -*-
import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation

wb = openpyxl.Workbook()
sheet = wb.active
sheet.title = 'sheet1'
fsheet = wb.create_sheet('form')

list = ['Ａ','Ｂ','Ｃ','Ｄ','Ｅ']
for i in range(len(list)):
    fsheet.cell(i+1, 1).value = list[i]

states = "北海道,青森県,岩手県,宮城県,秋田県,山形県,福島県,群馬県,栃木県,茨城県,埼玉県,千葉県," \
         "東京都,神奈川県,新潟県,富山県,石川県,福井県,山梨県,長野県,岐阜県,静岡県,愛知県,三重県,滋賀県," \
         "京都府,大阪府,兵庫県,奈良県,和歌山県,鳥取県,島根県,岡山県,広島県,山口県,徳島県,香川県,愛媛県," \
         "高知県,福岡県,佐賀県,長崎県,熊本県,大分県,宮崎県,鹿児島県,沖縄県"
states = states.split(",")
for i in range(len(states)):
    fsheet.cell(i+1, 2).value = states[i]

sheet.cell(1, 1, 'A')

dv1 = DataValidation(type="list", formula1='"A,B,C"')
dv1.add(sheet.cell(2, 1))
#  sheetname = "case" !$A $1 : $A $リスト長さ
dv2 = DataValidation(type="list", formula1="form!$A$1:$A$%d" % len(list))
dv2.add(sheet.cell(2, 2))

stateValidate = DataValidation(type="list", formula1="form!$B$1:$B$%d" % len(states))
# stateValidate.add( sheet.cell(2, 3) )
# stateValidate.add( sheet.cell(3, 3) )
stateValidate.ranges = 'C2 C3 D1:D1048576'
print(stateValidate.ranges)


sheet.add_data_validation(dv1)
sheet.add_data_validation(dv2)
sheet.add_data_validation(stateValidate)

wb.save('test.xlsx')
