# -*- coding: utf-8 -*-
# 参考: https://qiita.com/nezumi/items/23c301c661f5e9653f19
import xlrd

def excel_datetime(num):
    from datetime import datetime, timedelta
    return(datetime(1899, 12, 30) + timedelta(days=num))

def excel_date(num):
    from datetime import datetime, timedelta
    return(datetime(1899, 12, 30) + timedelta(days=num)).strftime("%Y/%m/%d")


book = xlrd.open_workbook('sample.xlsx')
sheet = book.sheet_by_index(0)
for row in range(1, sheet.nrows):
    #print("%s %s %d %s %s" % (sheet.cell(row, 0).value,
    #                        sheet.cell(row, 1).value,
    #                        sheet.cell(row, 2).value,
    #                        excel_date(sheet.cell(row, 3).value), excel_date(sheet.cell(row, 4).value) ) )
    #for col in range(sheet.ncols):
    #   print(sheet.cell(row, col).value)
    str = "'%s',  %d, TO_DATE('%s','YYYY/MM/DD')" % (
        sheet.cell(row, 0).value,
        sheet.cell(row, 1).value,
        excel_date(sheet.cell(row, 2).value)
        )
    print(str)

