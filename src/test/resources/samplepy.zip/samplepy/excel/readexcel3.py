# -*- coding: utf-8 -*-
# 参考: https://qiita.com/nezumi/items/23c301c661f5e9653f19
import xlrd

def excel_date(num):
    from datetime import datetime, timedelta
    return(datetime(1899, 12, 30) + timedelta(days=num)).strftime("%Y/%m/%d")
if __name__ == '__main__':
    book = xlrd.open_workbook('sample.xlsx')
    sheet = book.sheet_by_index(0)
    for row in range(1, sheet.nrows):
        str = "'%s',  %d, TO_DATE('%s','YYYY/MM/DD')" % (
            sheet.cell(row, 0).value,
            sheet.cell(row, 1).value,
            excel_date(sheet.cell(row, 2).value)
            )
        print(str)

    (ac) = (2,)
    print("ac = %s" % ac)