# -*- coding: utf-8 -*-
# 参考: https://qiita.com/nezumi/items/23c301c661f5e9653f19
#  https://xlrd.readthedocs.io/en/latest/api.html
import xlrd

def excel_datetime(num):
    from datetime import datetime, timedelta
    return(datetime(1899, 12, 30) + timedelta(days=num))

def excel_date(num):
    from datetime import datetime, timedelta
    return(datetime(1899, 12, 30) + timedelta(days=num)).strftime("%Y/%m/%d")

book = xlrd.open_workbook('sample.xlsx')
sheet = book.sheet_by_index(0)
for row in range(1, sheet.nrows):
    print("%s %d %s" % (sheet.cell_value(row, 0), sheet.cell_value(row, 1), sheet.cell_value(row, 2) ) )
    #print("%d %d %d" % (sheet.cell_type(row, 0), sheet.cell_type(row, 1), sheet.cell_type(row, 2) ) )