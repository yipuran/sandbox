# -*- coding: UTF-8 -*-
#  openpyxl     https://openpyxl.readthedocs.io/en/stable/
import openpyxl

wb = openpyxl.load_workbook("test.xlsx")
sheet = wb.get_sheet_by_name('sheet1')
# ws = wb.active
print("%s" % sheet.cell(1, 2).value)

#Sheetの名前を設定
#sheet.title = "Sheet1"
v = sheet.cell(3, 2).value
print("v = %s" % v)
sheet.cell(3, 2).value =  'う'

list = [chr(i) for i in range(ord('a'), ord('z') +1)]
for ix in range(len(list)):
    sheet.cell(ix + 2, 1).value = list[ix]


# 日本語もOK
#ws["B1"] = "あいうえお"

# 数字もOK
#ws["A3"] = 13

# Save the file
wb.save("test.xlsx")



