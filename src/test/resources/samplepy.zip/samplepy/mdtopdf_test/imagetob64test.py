# -*- coding: UTF-8 -*-
import base64
import glob
import re

def imageToB64encode(path):
    with open(path, 'rb') as f:
        return base64.b64encode(f.read()).decode()

image64str = imageToB64encode('images/menulink.jpg')
print(image64str)

for mdfile in glob.glob("*.md"):
    pdffile = re.sub('\.md$', '.pdf', mdfile)
    print(pdffile)