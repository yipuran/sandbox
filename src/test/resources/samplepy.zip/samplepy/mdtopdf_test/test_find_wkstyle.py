# -*- coding: utf-8 -*-
import os
import re

def find_all(directory):
    for root, dirs, files in os.walk(directory):
        yield root
        for file in files:
            yield os.path.join(root, file)

# カレントディレクトリから１番最初に見つかるファイル相対PATHを取得
def onefind_path(filename):
    for path in find_all('.'):
        if re.search(filename + '$', path):
            return path
    exit(1)

path = onefind_path('wkstyle.less')
print(path)

text =  """\
@import "mume/あああ/eee"
@import "mume/あああ/e11ee"
# AAA
## nnn
"""
print("=============")
print(text)
print("=============")
text = re.sub('@import ".+"\n', '', text)
print(text)

print("=============")
