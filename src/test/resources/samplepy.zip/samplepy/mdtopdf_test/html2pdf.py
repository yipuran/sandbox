# -*- coding: utf-8 -*-
#  HTML → PDF
import pdfkit
import base64
import re
import os
import glob

options = {
    'page-size': 'A4',
    'margin-top': '0.75in',
    'margin-right': '0.75in',
    'margin-bottom': '0.75in',
    'margin-left': '0.75in',
    'encoding': "UTF-8"
}
# 画像ファイル→ Base64 エンコード
def imageToB64encode(path):
    with open(path, 'rb') as f:
        return base64.b64encode(f.read()).decode()

# HTML 読込 PDF作成
def convertPDF(htmlpath, pdfpath):
    with open(htmlpath, 'rt', encoding="utf-8") as f:
        body = f.read()
        print(body)
        # 画像は、base64 エンコードして <img src=data:image/png;base64,base64エンコード文字列"/> にする。
        for imgtag in re.findall('<img .* src=".+"', body):
            s = re.search('src=".+"', imgtag).group(0).replace('src="', '').replace('"', '')
            imgval = re.search('<img .* ', imgtag).group(0)
            imgval += 'src="data:image/' + s[-3:] + ';base64,' + imageToB64encode(s) + '"'
            body = body.replace(imgtag, imgval)
        # PDFで出力
        pdfkit.from_string(body, pdfpath, options=options)

#########################
if __name__ == '__main__':
    for htmlfile in glob.glob("*.html"):
        pdfname = re.sub('\.html$', '.pdf', htmlfile)
        convertPDF(htmlfile, pdfname)
        print("%s → %s" % (htmlfile, pdfname))

