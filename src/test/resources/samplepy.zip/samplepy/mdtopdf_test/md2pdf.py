# -*- coding: UTF-8 -*-
import markdown
import pdfkit
import base64
import re
import os
import glob

options = {
    'page-size': 'A4',
    'margin-top': '0.75in',
    'margin-right': '0.75in',
    'margin-bottom': '0.75in',
    'margin-left': '0.75in',
    'encoding': "UTF-8"
}

# Markdown 拡張、表と目次
mdextensions = [ "tables", "toc" ]

# ディレクトリ全探索
def find_all(directory):
    for root, dirs, files in os.walk(directory):
        yield root
        for file in files:
            yield os.path.join(root, file)

# カレントディレクトリから１番最初に見つかるファイル相対PATHを取得
def onefind_path(filename):
    for path in find_all('.'):
        if re.search(filename + '$', path):
            return path
    exit(1)

# 画像ファイル→ Base64 エンコード
def imageToB64encode(path):
    with open(path, 'rb') as f:
        return base64.b64encode(f.read()).decode()

# md ファイル → PDF
def convertPDF(mdpath, pdfpath, style):
    with open(mdpath, 'rt', encoding="utf-8") as f:
        text = f.read()
        # Markdown の import 文を除去
        text = re.sub('@import ".+"\n', '', text)
        # HTMLに変換
        body = markdown.Markdown(extensions=mdextensions).convert(text)
        # 画像は、base64 エンコードして <img src=data:image/png;base64,base64エンコード文字列"/> にする。
        for imgtag in re.findall('<img .* src=".+"', body):
            #print(imgtag)
            s = re.search('src=".+"', imgtag).group(0).replace('src="', '').replace('"', '')
            imgval = re.search('<img .* ', imgtag).group(0)
            imgval += 'src="data:image/' + s[-3:] + ';base64,' + imageToB64encode(s) + '"'
            body = body.replace(imgtag, imgval)
        html = '<html lang="ja"><meta charset="utf-8">'
        html += '<style>' + style + '</style>'
        html += '<body>' + body + '</body></html>'
        # PDFで出力
        pdfkit.from_string(html, pdfpath, options=options)

#########################
if __name__ == '__main__':
    # スタイルは、固定 wkstyle.less で 読込
    with open(onefind_path('wkstyle.less'), 'rt', encoding="utf-8") as f:
        wkstyle = f.read()
        for mdfile in glob.glob("*.md"):
            pdfname = re.sub('\.md$', '.pdf', mdfile)
            convertPDF(mdfile, pdfname, wkstyle)
            print("-----------------------------------")
            print("%s → %s" % (mdfile, pdfname))
