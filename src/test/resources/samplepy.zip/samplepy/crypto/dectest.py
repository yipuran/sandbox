# -*- coding: UTF-8 -*-
# pycryptodome

from base64 import b64decode
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP

print("----　privatekey　と 暗合化されたテキスト読込み --------")
with open("c:/work/privatekey.txt" , "r") as f:
    privatekey = f.read()
    rsakey = RSA.importKey(b64decode(privatekey))


#with open("c:/work/encrypt.txt") as f:
#    encrypt = f.read()
#print("privatekey : %s" % privatekey)
#print("encrypt : %s" % encrypt)


#rsakey = RSA.importKey(privatekey)
#rsakey = PKCS1_OAEP.new(rsakey)

##rsakey = RSA.importKey( b64decode(privatekey) )