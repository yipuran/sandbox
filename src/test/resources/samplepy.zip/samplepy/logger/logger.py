# -*- coding: UTF-8 -*-
# logger.py
#　　Usage:
#        from logger import Logger
#        logger = Logger("aaa")
#　　　　logger.debug("■ %s" % "test＿あ")
#
from logging import Formatter, handlers, StreamHandler, getLogger, DEBUG, WARN
import inspect

class Logger:
    def __init__(self, name=__name__):
        if name=="logger":
            name = inspect.getmodule(inspect.stack()[1][0]).__name__
        self.logger = getLogger(name)
        self.logger.setLevel(DEBUG)
        formatter = Formatter(fmt="%(asctime)s.%(msecs)03d %(levelname)7s %(message)s [%(name)s  %(processName)s - %(threadName)s]", datefmt="%Y/%m/%d %H:%M:%S")
        ### WARN レベルまで標準出力する ###
        sthandler = StreamHandler()
        sthandler.setLevel(WARN)
        sthandler.setFormatter(formatter)
        self.logger.addHandler(sthandler)

        ### 時刻ローテーション ###
        handler = handlers.TimedRotatingFileHandler(filename='/var/log/test.log',
                                                    encoding='UTF-8',
                                                    when='D',
                                                    backupCount=7 )
        ### サイズローテーション ###
        ''' 
       handler = handlers.RotatingFileHandler(filename='/var/log/test.log',
                                               encoding='UTF-8',
                                               maxBytes=1048576,
                                               backupCount=3)
       '''
        ############################
        handler.setLevel(DEBUG)
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)

    def debug(self, msg):
        self.logger.debug(msg)

    def info(self, msg):
        self.logger.info(msg)

    def warn(self, msg):
        self.logger.warning(msg)

    def error(self, msg):
        self.logger.error(msg)

    def critical(self, msg):
        self.logger.critical(msg)