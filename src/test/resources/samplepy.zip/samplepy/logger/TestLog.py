# -*- coding: UTF-8 -*-

#import logger
from logger import Logger
# logger = logger.Logger("ABC")

print("#### %s" % __name__)

logger = Logger("aaa")
logger.debug("test message : あいうえお")
logger.info("test message : あいうえお")
logger.warn("test message : あいうえお")
logger.error("test message : あいうえお")
logger.info("test message : あいうえお")