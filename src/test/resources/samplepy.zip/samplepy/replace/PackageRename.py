# -*- coding: utf-8 -*-

# 参考：https://qiita.com/amowwee/items/e63b3610ea750f7dba1b
#     https://code.i-harness.com/ja/q/1058c96

import os
import sys
import glob
from pathlib import Path

def replace_word(infile, old_word, new_word):
    if not os.path.isfile(infile):
        print ("Error on replace_word, not a regular file : " + infile)
        sys.exit(1)
    f1 = open(infile, 'r', encoding='utf-8').read()
    f2 = open(infile, 'w', encoding='utf-8')
    f2.write(f1.replace(old_word, new_word))

#--------------------
#for file in glob.glob('c:/work/karas/**/*.java', recursive=True):
#    print("%s" % file)

p = Path("c:/work/jacobsrc/")
for file in p.glob("**/*.java"):
    print("%s" % file)
    replace_word(file, "org.jacob", "jp.co.worldamenity.karas.jacob")
    print("complete!!")
