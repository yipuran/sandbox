# -*- coding: UTF-8 -*-

from pathlib import Path


p = Path("c:/work/karas/")
for file in p.glob("**/*.java"):
    print("%s" % file)
