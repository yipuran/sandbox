# -*- coding: utf-8 -*-

#import os
#import sys
import glob


for file in glob.glob('c:/work/karas/**/*.java', recursive=True):
    print("%s" % file)