# -*- coding: UTF-8 -*-
import datetime

def bbb():
    print("bbb")

class Testclass:
    def __init__(self, a=12, b='Miran'):
        print("testclass:__init__ %02d %s" % (a, b))
    def aaa(self):
        print("aaa")


#if __name__ == '__main__' :
#    print("main START")
#    t = Testclass(9, datetime.datetime.today() )
#    t.aaa()