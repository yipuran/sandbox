# -*- coding: UTF-8 -*-
import testclass
from testclass import Testclass

# tt = Testclass(1, "aaa")

tt = Testclass()

tt.aaa()
testclass.bbb()