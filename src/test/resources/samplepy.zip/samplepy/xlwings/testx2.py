# -*- coding: UTF-8 -*-
import xlwings as xw

def toCamelCase(string, titleCase=False):
    import re
    if titleCase:
        return ''.join(x.title() for x in string.split('_'))
    else:
        return re.sub("_(.)", lambda m:m.group(1).upper(), string.lower())

def toSnakeCase(string, upper=False):
    import re
    if upper:
        return re.sub("(.[A-Z])",
                      lambda x: x.group(1)[0] + "_" + x.group(1)[1],
                      string).lower().upper()
    else:
        return re.sub("(.[A-Z])",
                      lambda x:x.group(1)[0] + "_" +x.group(1)[1],
                      string).lower()

xb = xw.Book("SnakeCamel変換.xlsx")
sheet = xb.sheets[0]

Bmax = sheet.range('B3').current_region.last_cell.row
Dmax = sheet.range('D3').current_region.last_cell.row
print("B max = %d" % Bmax)
print("D max = %d" % Dmax)

for i in range(4, sheet.range('B3').current_region.last_cell.row + 1):
    snakestr = sheet.range("B%d" % i).value
    sheet.range("D%d" % i).value = toCamelCase(snakestr)
    cs =  toCamelCase(snakestr)
    print("%s : %s → %s" % (("B%d" % i) , snakestr , cs ) )

print("---------")
for i in range(4, sheet.range('D3').current_region.last_cell.row + 1):
    camelstr = sheet.range("D%d" % i).value
    print("%s → %s" % (("D%d" % i) , camelstr))

