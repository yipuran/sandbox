# -*- coding: UTF-8 -*-
import xlwings as xw

def toCamelCase(string, titleCase=False):
    import re
    if titleCase:
        return ''.join(x.title() for x in string.split('_'))
    else:
        return re.sub("_(.)", lambda m:m.group(1).upper(), string.lower())
def toSnakeCase(string, upper=False):
    import re
    if upper:
        return re.sub("(.[A-Z])", lambda x: x.group(1)[0] + "_" + x.group(1)[1], string).lower().upper()
    else:
        return re.sub("(.[A-Z])", lambda x:x.group(1)[0] + "_" +x.group(1)[1], string).lower()

def writeCamel():
    sheet = xw.sheets[0]
    if sheet.range('B1').value:
        for i in range(4, sheet.range('B3').current_region.last_cell.row + 1):
            snakestr = sheet.range("B%d" % i).value
            sheet.range("D%d" % i).value = toCamelCase(snakestr, True)
    else:
        for i in range(4, sheet.range('B3').current_region.last_cell.row + 1):
            snakestr = sheet.range("B%d" % i).value
            sheet.range("D%d" % i).value = toCamelCase(snakestr)
def writeSnake():
    sheet = xw.sheets[0]
    if sheet.range('D1').value:
        for i in range(4, sheet.range('D3').current_region.last_cell.row + 1):
            camelstr = sheet.range("D%d" % i).value
            sheet.range("B%d" % i).value = toSnakeCase(camelstr, True)
    else:
        for i in range(4, sheet.range('D3').current_region.last_cell.row + 1):
            camelstr = sheet.range("D%d" % i).value
            sheet.range("B%d" % i).value = toSnakeCase(camelstr)
