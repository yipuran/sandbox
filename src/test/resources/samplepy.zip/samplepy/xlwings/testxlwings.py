# -*- coding: UTF-8 -*-
import xlwings as xw
#import openpyxl
#  ['C:\\Programs\\Python3.6.5\\lib\\site-packages\\xlwings']

def helloe():
    a1cell = xw.sheets[0].range("B1").value
    #print(a1cell)
    xw.sheets[0].range("B3").value = a1cell

# xb = xw.Book("sample.xlsm")
# print("A1 = %s" % xb.sheets[0].range('A1').value)
# print("B1 = %s" % xb.sheets[0].range('B1').value)
# print("J1 = %s" % xb.sheets[0].range('J1').value)
#
# book = openpyxl.load_workbook("sample.xlsm")
# print("row = %d" % book['Sheet1'].max_row)
#
# rownum = xb.sheets[0].range('A1').current_region.last_cell.row
# print("row = %d" % rownum)
