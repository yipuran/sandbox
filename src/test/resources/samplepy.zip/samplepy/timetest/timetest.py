# -*- coding: UTF-8 -*-
from random import randint
from datetime import datetime
from datetime import timedelta


def minutes_expand(from_datetime, to_datetime):
    result = []
    for x in range(0, int((to_datetime-from_datetime).seconds / 60) + 1):
        result.append(from_datetime + timedelta(minutes=x))
    return result
# datetime.strptime -> strptime
strptime = datetime.strptime

# for t in minutes_expand(strptime('2019-02-26 00:00', '%Y-%m-%d %H:%M'),
#                         strptime('2019-02-26 00:10', '%Y-%m-%d %H:%M')):
#      print("'%s'" % t.strftime('%Y/%m/%d %H:%M:%S'))


print('--------------')
t2 = datetime.today() + timedelta(days=-1)
# print("'%s'" % t2.strftime('%Y/%m/%d %H:%M:%S'))

fromtime = (datetime.today() + timedelta(days=-1)).strftime('%Y-%m-%d 00:00')
totime = (datetime.today() + timedelta(days=-1)).strftime('%Y-%m-%d 00:09')
print(fromtime)
print(totime)
for t in minutes_expand(strptime(fromtime, '%Y-%m-%d %H:%M'), strptime(totime, '%Y-%m-%d %H:%M')):
    print("'%s'" % t.strftime('%Y/%m/%d %H:%M:%S'))
    v = randint(0, 100)
    print("%d" % v)
