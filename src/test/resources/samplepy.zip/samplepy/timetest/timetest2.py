# -*- coding: UTF-8 -*-

from datetime import datetime
from datetime import timedelta

# datetime.strptime -> strptime
strptime = datetime.strptime

# 時刻分の展開
def minutes_expand(from_datetime, to_datetime):
    result = []
    for x in range(0, int((to_datetime-from_datetime).seconds / 60) + 1):
        result.append(from_datetime + timedelta(minutes=x))
    return result

end = datetime.now().strftime('%Y/%m/%d %H:%M:00')
print("%s" % end)
today_from = datetime.today().strftime('%Y-%m-%d 00:00')
today_to = datetime.now().strftime('%Y-%m-%d %H:%M')

for t in minutes_expand(strptime(today_from, '%Y-%m-%d %H:%M'), strptime(today_to, '%Y-%m-%d %H:%M')):
    print(t)