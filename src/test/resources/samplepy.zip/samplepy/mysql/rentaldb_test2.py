# -*- coding: UTF-8 -*-

from urllib.parse import urlparse
from mysqlConnector import MySQLConnector
import mysql.connector

'''
conn = mysql.connector.connect(host='localhost', port=3308, user='master', password='rental2man', database='rentaldb')
if conn.is_connected():
    cur = conn.cursor()
    cur.execute('SELECT * FROM depots')

    table = cur.fetchall()
    print(table)

    conn.close()
'''
with MySQLConnector(host='localhost', port=3308, user='master', password='rental2man', database='rentaldb') as conn:
    cur = conn.cursor()
    cur.execute('SELECT * FROM depots')
    table = cur.fetchall()
    print(table)
