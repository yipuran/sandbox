# -*- coding: UTF-8 -*-
from urllib.parse import urlparse
import mysql.connector

conn = mysql.connector.connect(host='54.95.21.47', port=3306, user='wsysman', password='p2vx01zun', database='wsysdb')
if conn.is_connected():
    print("OK")
    conn.close()
else:
    print("NG")