# -*- coding: UTF-8 -*-
from urllib.parse import urlparse
import mysql.connector

url = urlparse('mysql://master:rental2man@localhost:3308/rentaldb')

conn = mysql.connector.connect(
    host = url.hostname or 'localhost',
    port = url.port or 3308,
    user = url.username or 'master',
    password = url.password or 'rental2man',
    database = url.path[1:],
)

#conn.is_connected()

cur = conn.cursor()
cur.execute('SELECT * FROM depots')

table = cur.fetchall()
print(table)


conn.close()
