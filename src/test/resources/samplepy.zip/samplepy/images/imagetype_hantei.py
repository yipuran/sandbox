# -*- coding: UTF-8 -*-
import re
import sys


def is_jpg(b: bytes) -> bool:
    """バイナリの先頭部分からJPEGファイルかどうかを判定する。"""
    return bool(re.match(br"^\xff\xd8", b[:2]))


def is_png(b: bytes) -> bool:
    """バイナリの先頭部分からPNGファイルかどうかを判定する。"""
    return bool(re.match(br"^\x89\x50\x4e\x47\x0d\x0a\x1a\x0a", b[:8]))


def is_gif(b: bytes) -> bool:
    """バイナリの先頭部分からGIFファイルかどうかを判定する。"""
    return bool(re.match(br"^\x47\x49\x46\x38", b[:4]))


def main():
    checkers = (is_jpg, is_png, is_gif,)
    data = sys.stdin.buffer.read()
    return any(checker(data) for checker in checkers)


if __name__ == '__main__':
    if main():
        sys.exit(0)
    else:
        sys.exit("Input data is invalid image data.")
