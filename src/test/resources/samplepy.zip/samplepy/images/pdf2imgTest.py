# -*- coding: UTF-8 -*-

from pdf2image import convert_from_path
path = 'c:/work/MyBatis-3-User-Guide_5.pdf'
images = convert_from_path(path)
i = 0
for image in images:
    image.save('test{}.png'.format(i), 'png')
    i += 1
