# -*- coding: UTF-8 -*-

from PIL import Image

img = Image.open('lena.png')

img_resize = img.resize((256, 256))
img_resize.save('lena_llow_resize_nearest.png')

img_resize_lanczos = img.resize((256, 256), Image.LANCZOS)
img_resize_lanczos.save('lena_lanczos.png')

img.thumbnail((64, 64), Image.LANCZOS)
img.save('lena_t.png')
