# -*- coding: utf-8 -*-
from PIL import Image

img = Image.open("C:/work/auqid.jpg")
# サイズ取得
width, height = img.size
# 作成
img.thumbnail((int(width/2), int(height/2)), Image.LANCZOS)
# 保存
img.save("C:/work/auqid_A.jpg")

print("finish")

