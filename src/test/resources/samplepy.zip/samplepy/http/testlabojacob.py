# -*- coding: utf-8 -*-

import urllib.request
import json

req = urllib.request.Request("http://localhost:8080/labojacob/sample")
#req.add_header("X-CUSTOM-MIDORI", "My Midori")

# 送信
with urllib.request.urlopen(req) as res:
    stscode = res.getcode()
    headers = res.info()
    print("status = %d" % stscode)
    print("----- HTTP headers -------")
    print(headers)
    print("--------------------------")
    #body = res.read().decode('Shift-JIS')
    body = res.read().decode('utf-8')
    print(body)
    for key, value in json.loads(body).items():
        print("key = %s   value = %s " % (key, value))
