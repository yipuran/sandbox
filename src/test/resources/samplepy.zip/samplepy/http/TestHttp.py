# -*- coding: utf-8 -*-

import urllib.request

req = urllib.request.Request("http://localhost:8080/mincjacob/sample")
req.add_header("X-CUSTOM-MIDORI", "My Midori")

# 送信
with urllib.request.urlopen(req) as res:
    stscode = res.getcode()
    headers = res.info()
    print("status = %d" % stscode)
    print("----- HTTP headers -------")
    print(headers)
    print("--------------------------")
    print("mincjacob-key = %s" % headers['mincjacob-key'] )





