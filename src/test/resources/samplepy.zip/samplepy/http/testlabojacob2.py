# -*- coding: utf-8 -*-

from urllib.request import build_opener, HTTPCookieProcessor
from urllib.parse import urlencode
from http.cookiejar import CookieJar
import json

opener = build_opener(HTTPCookieProcessor(CookieJar()))

data = {
    'name':'test-ABC',
    'point': 123,
    'info': 'テスト'
}
senddata = urlencode(data).encode('utf-8')

with opener.open('http://localhost:8080/labojacob/sample', senddata) as res:
    headers = res.getheaders()
    print("------ HTTP-Headers ------")
    for h in headers:
        print("[%s] = [%s]" % (h[0], h[1]))
    print("--------------------------")
    body = res.read().decode('utf-8')
    print(body)
    for key, value in json.loads(body).items():
        print("key = %s   value = %s " % (key, value))
