# -*- coding: UTF-8 -*-

import urllib.request

req = urllib.request.Request("http://localhost:8080/LaboWeb/")

with urllib.request.urlopen(req) as res:
    body = res.read().decode('utf-8')
    print(body)